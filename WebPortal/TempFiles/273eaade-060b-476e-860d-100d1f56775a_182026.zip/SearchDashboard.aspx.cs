using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class OST_SearchDashboard : Page
{
    private static readonly HashSet<string> AllowedTabs = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "OrderAllocationTest",
        "ProcessOrderPM",
        "UploadAndDownloadSearch",
        "EditCosting"
    };

    private string ActiveTab
    {
        get
        {
            string value = Convert.ToString(ViewState["SearchDashboardActiveTab"]);
            return AllowedTabs.Contains(value) ? value : "OrderAllocationTest";
        }
        set
        {
            ViewState["SearchDashboardActiveTab"] = AllowedTabs.Contains(value)
                ? value
                : "OrderAllocationTest";
        }
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        string requestedTab = Request.QueryString["tab"];
        if (AllowedTabs.Contains(requestedTab))
            ActiveTab = requestedTab;

        LoadActiveModule();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        SetMasterHeading();
        ApplyActiveTabState();
    }

    protected void DashboardTab_Command(object sender, CommandEventArgs e)
    {
        string selectedTab = Convert.ToString(e.CommandArgument);
        if (!AllowedTabs.Contains(selectedTab)) return;

        ActiveTab = selectedTab;
        Response.Redirect("SearchDashboard.aspx?tab=" + Server.UrlEncode(selectedTab), false);
        Context.ApplicationInstance.CompleteRequest();
    }

    protected void ddlDashboardTab_SelectedIndexChanged(object sender, EventArgs e)
    {
        string selectedTab = ddlDashboardTab.SelectedValue;
        if (!AllowedTabs.Contains(selectedTab)) return;

        ActiveTab = selectedTab;
        Response.Redirect("SearchDashboard.aspx?tab=" + Server.UrlEncode(selectedTab), false);
        Context.ApplicationInstance.CompleteRequest();
    }

    private void LoadActiveModule()
    {
        string controlPath;
        switch (ActiveTab)
        {
            case "ProcessOrderPM":
                controlPath = "~/OST/ucProcessOrderPM.ascx";
                break;
            case "UploadAndDownloadSearch":
                controlPath = "~/OST/ucUploadAndDownloadSearch.ascx";
                break;
            case "EditCosting":
                controlPath = "~/OST/ucEditCosting.ascx";
                break;
            default:
                controlPath = "~/OST/ucOrderAllocationTest.ascx";
                break;
        }

        Control module = LoadControl(controlPath);
        module.ID = "ActiveDashboardModule";
        phDashboardContent.Controls.Add(module);
    }

    private void SetMasterHeading()
    {
        HtmlGenericControl header = Master.FindControl("header") as HtmlGenericControl;
        HtmlGenericControl breadcrumb = Master.FindControl("brdcrm") as HtmlGenericControl;

        if (header != null) header.InnerText = "Search Dashboard";
        if (breadcrumb != null) breadcrumb.InnerText = "Search Dashboard";
    }

    private void ApplyActiveTabState()
    {
        hfActiveTab.Value = ActiveTab;
        ddlDashboardTab.SelectedValue = ActiveTab;

        SetTabClass(tabOrderAllocationTest, "OrderAllocationTest");
        SetTabClass(tabProcessOrderPM, "ProcessOrderPM");
        SetTabClass(tabUploadAndDownloadSearch, "UploadAndDownloadSearch");
        SetTabClass(tabEditCosting, "EditCosting");
    }

    private void SetTabClass(LinkButton button, string tabName)
    {
        button.CssClass = "search-dashboard__tab" +
            (ActiveTab.Equals(tabName, StringComparison.OrdinalIgnoreCase) ? " is-active" : string.Empty);
        button.Attributes["aria-selected"] = ActiveTab.Equals(tabName, StringComparison.OrdinalIgnoreCase)
            ? "true"
            : "false";
    }
}
