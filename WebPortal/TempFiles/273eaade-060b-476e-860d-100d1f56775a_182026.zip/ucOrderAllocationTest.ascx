<%@ Control Language="C#" AutoEventWireup="true" CodeFile="ucOrderAllocationTest.ascx.cs" Inherits="ucOrderAllocationTest" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="asp" %>
<%@ Register Assembly="DevExpress.Web.v14.2, Version=14.2.3.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Namespace="DevExpress.Web" TagPrefix="dx" %>

<div class="search-dashboard-module search-dashboard-module--orderallocationtest">

    
    <style>
        .grd1 {
            width: 100%;
            text-align: center;
            font-size:12px;
        }

            .grd1 th {
                padding: 3px;
                text-align: center;
            }

            .grd1 td {
                padding: 3px;
            }
    </style>
    <script type="text/javascript">

        function HideLabel() {
            var seconds = 5;
            setTimeout(function () {
                document.getElementById("<%=dvError.ClientID %>").style.display = "none";
            }, seconds * 1000);
        };

        function CheckAll(oCheckbox) {
            var GridView2 = document.getElementById("<%=grdProject.ClientID %>");
            for (i = 1; i < GridView2.rows.length; i++) {
                GridView2.rows[i].cells[0].getElementsByTagName("INPUT")[0].checked = oCheckbox.checked;
            }
        }


    </script>

    <script type="text/javascript">
        function checkDate(sender, args) {
            var Dt = new Date();
            if (Date.parse(sender._selectedDate) > new Date()) {

                alert("You cannot set Future Date!");
                sender._selectedDate = new Date();
                // set the date back to the current date
                sender._textbox.set_Value(sender._selectedDate.format(sender._format))
            }
        }

    </script>

    <script>
        function onSelectAll(s, e) {
            $(
    '[id*="CheckBox1"]').each(function () {
        try {
            eval($(this)[0].id).SetChecked(s.GetChecked());
        }

        catch (err) { }
    });

        }

        var startTime;
        function OnBeginCallback_AutoComplete() {
            startTime = new Date();
        }
        function OnEndCallback_AutoComplete() {
            var result = new Date() - startTime;
            result /= 1000;
            result = result.toString();
            if (result.length > 4)
                result = result.substr(0, 4);
            time.SetText(result.toString() + " sec");
            label.SetText("Time to retrieve the last data:");
        }
    </script>



    <link href="../bootstrap/css/TabContainer.css" rel="stylesheet" />


    <asp:Button ID="btnHidden" runat="server" OnClick="btnHidden_Click" Style="display: none;" />
    <div id="BACK" runat="server" style="width: 100%; display: none;">
        <asp:LinkButton ID="LinkButton" runat="server" Style="float: right; padding-right: 150px; font-size: 15px; font-weight: bold" OnClick="LinkButton_Click"><< Back</asp:LinkButton>

    </div>
    <center>
        <div id="dvError" runat="server" style="display:none; padding-bottom:20px;">
            <asp:Label ID="lblError" runat="server"  ForeColor="Red"></asp:Label>
        </div>
        <div id="dvMsg" runat="server">
            <asp:Label ID="lblAutoRefMsg" runat="server"  ForeColor="Red"></asp:Label>
        </div>
    </center>
    
    <div class="col-sm-12">
        <asp:TabContainer runat="server" ActiveTabIndex="0" ID="TabOrderAllocation" CssClass="fancy fancy-green">

            <asp:TabPanel ID="TabPanel1" runat="server" HeaderText="PM Allocation" CssClass="panel">
                <HeaderTemplate>
                    <div class="divTab">Manual Allocation</div>
                </HeaderTemplate>
                <ContentTemplate>
                    <table id="Table7" class="table" runat="server">
                        <tr>
                            <td width="120px"><b>Project # : </b></td>
                            <td colspan="4">
                                <asp:DropDownList ID="drpProjectPM" runat="server" Width="100px" Height="25px" OnSelectedIndexChanged="drpProjectPM_SelectedIndexChanged" AutoPostBack="true"></asp:DropDownList>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                                    <b>Process :</b>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                                    <asp:DropDownList ID="drpProcess" runat="server" Width="100px" Height="25px" OnSelectedIndexChanged="drpProcess_SelectedIndexChanged" AutoPostBack="true"></asp:DropDownList>

                                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="drpProcess" ValidationGroup="Queue"
                                    Display="Dynamic" ErrorMessage="Please Select Process" SetFocusOnError="true" ForeColor="Red" Font-Size="11px"
                                    InitialValue="Select"></asp:RequiredFieldValidator>

                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                                 <b>Date : </b>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp
                                    <asp:TextBox ID="txtDate" runat="server" Height="25px" Width="100px" ReadOnly="true"></asp:TextBox>
                               
                            </td>
                        </tr>
                        <tr>

                            <td></td>
                            <td colspan="4" style="text-align: center">
                                <div style="width: 550px;">
                                    
                                    <asp:GridView ID="grdPendingOrder" runat="server" EmptyDataText="No Record(s) Found." AutoGenerateColumns="false" OnSelectedIndexChanged="GrdPendingOrder1_SelectedIndexChanged" HeaderStyle-BackColor="#F0F1F5" CssClass="grd1" HeaderStyle-Font-Size="12px">
                                        <Columns>
                                            <asp:BoundField DataField="OrderDate" HeaderText="OrderDate" />
                                            <asp:BoundField DataField="ProjectNumber" HeaderText="ProjectNumber" />
                                            <asp:BoundField DataField="ProductType" HeaderText="ProductType" />
                                            <asp:BoundField DataField="Count" HeaderText="Count" />
                                            <asp:CommandField ButtonType="Image" ShowSelectButton="true" SelectImageUrl="../Images/Edit.png" HeaderText="Select" />

                                        </Columns>
                                    </asp:GridView>
                                </div>
                            </td>

                        </tr>

                        <tr>
                            <td width="120px"><b>Allocate To :</b> </td>
                            <td colspan="4">
                                <asp:DropDownList ID="ddlAllocateTo" runat="server" Width="100px" Height="25px" AutoPostBack="true" OnSelectedIndexChanged="ddlAllocateTo_SelectedIndexChanged">
                                    <asp:ListItem Value="Searcher">User</asp:ListItem>
                                    <asp:ListItem Value="Vendor">Vendor</asp:ListItem>
                                    <asp:ListItem Value="VM">VM</asp:ListItem>
                                </asp:DropDownList>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                      
                                <asp:DropDownList ID="ddlAllocateToPerson" runat="server" Width="320px" Height="25px">
                                </asp:DropDownList>

                                <asp:RequiredFieldValidator ID="RequiredFieldValidator_1" runat="server" ControlToValidate="ddlAllocateToPerson" ValidationGroup="Reg_1"
                                    Display="Dynamic" ErrorMessage="Please Select Allocate to Person Name" SetFocusOnError="True" ForeColor="Red" Font-Size="11px"
                                    InitialValue="Select"></asp:RequiredFieldValidator>
                            </td>

                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <asp:Button ID="btnPMAllocate" ValidationGroup="Reg_1" runat="server" Text="Allocate" Style="font-weight: bold; font-size: 14px; padding: 5px 10px;" OnClick="btnPMAllocate_Click" />
                            </td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </table>
                    <div style="overflow: auto;">
                        <asp:GridView ID="grdProject" runat="server" AutoGenerateColumns="false" DataKeyNames="OrderID" CssClass="grd1" HeaderStyle-BackColor="#F0F1F5" HeaderStyle-Font-Size="12px">
                            <Columns>
                                <asp:TemplateField HeaderStyle-Width="40px">
                                    <HeaderTemplate>
                                        <asp:CheckBox ID="chkHeader" runat="server" onclick="CheckAll(this)" />
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <asp:CheckBox ID="chkRow" runat="server" />
                                    </ItemTemplate>
                                </asp:TemplateField>
                                <asp:BoundField DataField="OrderID" HeaderText="OrderID" Visible="false" />
                                <asp:BoundField DataField="ProjectNumber" HeaderText="Project No." />
                                <asp:BoundField DataField="ClientOrderNo" HeaderText="Order No." />
                                <asp:BoundField DataField="OnOffLine" HeaderText="OnOffLine" />
                                <asp:BoundField DataField="OrderDateTime" HeaderText="Order DateTime" />
                                <asp:BoundField DataField="ProductType" HeaderText="Product Type" />
                                <asp:BoundField DataField="OrderPriority" HeaderText="OrderType"/>
                                <asp:BoundField DataField="BName" HeaderText="BName" />
                                <asp:BoundField DataField="PropertyAddress" HeaderText="Property Address" />
                                <asp:BoundField DataField="State" HeaderText="State" />
                                <asp:BoundField DataField="County" HeaderText="County" />
                                <asp:BoundField DataField="LastProcess" HeaderText="Last Process" />
                                <asp:BoundField DataField="LegalDescription" HeaderText="Legal Description" />
                                <asp:BoundField DataField="ClientIdNew" HeaderText="ClientId" />
                                <asp:BoundField DataField="CustomerType" HeaderText="Customer Type" />
                                <asp:BoundField DataField="Instruction" HeaderText="Instruction" />
                                <asp:BoundField DataField="Assign" HeaderText="Last User" />

                            </Columns>
                        </asp:GridView>
                        
                    </div>
                   
                    <div style="overflow: scroll; display:none;">
                         <h5>
                        <asp:Label ID="lblVendor" runat="server" Text=" Details" Font-Bold="true"></asp:Label>
                    </h5>
                        <dx:ASPxGridView ID="grdVendorDetails" runat="server" AutoGenerateColumns="false" KeyFieldName="OrderID" EnableRowsCache="False" Theme="Office2010Silver" Width="700px"
                            OnCustomCallback="grdVendorDetails_CustomCallback" OnCustomUnboundColumnData="grdVendorDetails_CustomUnboundColumnData">
                            <Columns>
                                <dx:GridViewDataTextColumn FieldName="" Caption="Project" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="" Caption="Process" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="" Caption="Records" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="" Caption="In-Process" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="" Caption="Completed" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                            </Columns>
                        </dx:ASPxGridView>
                    </div>
                </ContentTemplate>
            </asp:TabPanel>
            <asp:TabPanel ID="TabPanel7" runat="server" HeaderText="Order Queue" CssClass="panel">
                <HeaderTemplate>
                    <div class="divTab">User-InfinityOrderStatus</div>
                </HeaderTemplate>
                <ContentTemplate>
                    <table id="Table11" class="table" runat="server">
                        <tr>
                            <td>
                                <dx:ASPxGridView ID="grdOrderStatus" runat="server" AutoGenerateColumns="false" EnableRowsCache="False" Width="100%" Theme="Office2010Silver"
                                    OnCustomCallback="grdOrderStatus_CustomCallback" OnCustomUnboundColumnData="grdOrderStatus_CustomUnboundColumnData">
                                    <SettingsPager PageSize="1000"></SettingsPager>
                                    <Columns>
                                        <dx:GridViewDataTextColumn FieldName="Number" VisibleIndex="0" Caption="Sr. #" Width="40px" UnboundType="String" ReadOnly="true" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                        <dx:GridViewDataTextColumn FieldName="UserCode" Caption="Name" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                        <dx:GridViewDataTextColumn FieldName="WorkingBranch" Caption="Location" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                        <dx:GridViewDataTextColumn FieldName="InTime" Caption="In Time" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                        <dx:GridViewDataTextColumn FieldName="OrdersAssigned" Caption="Orders Assigned" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                        <dx:GridViewDataTextColumn FieldName="OrdersCompleted" Caption="Orders Completed" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                        <dx:GridViewDataTextColumn FieldName="Pending" Caption="Pending" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                                    </Columns>
                                </dx:ASPxGridView>
                            </td>
                        </tr>
                    </table>
                </ContentTemplate>
            </asp:TabPanel>
        </asp:TabContainer>
    </div>
    <div class="container"></div>

</div>
