<%@ Control Language="C#" AutoEventWireup="true" CodeFile="ucUploadAndDownloadSearch.ascx.cs" Inherits="ucUploadAndDownloadSearch" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="asp" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register Assembly="DevExpress.Web.v14.2, Version=14.2.3.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Namespace="DevExpress.Web" TagPrefix="dx" %>

<div class="search-dashboard-module search-dashboard-module--uploadanddownloadsearch">

    <link href="../bootstrap/css/TabContainer.css" rel="stylesheet" />
    <script type="text/javascript">
        function HideLabel() {
            var seconds = 5;
            setTimeout(function () {
                document.getElementById("<%=dvError.ClientID %>").style.display = "none";
            }, seconds * 1000);
        };
    </script>
    <script type="text/javascript">
        function Cleardropdown() {
            document.getElementById("<%=drpProjectPM.ClientID%>").value = "0";            

        }


    </script>


    <asp:HiddenField ID="hdfValue" runat="server" />
    <asp:HiddenField ID="hdID" runat="server" />
    <center>
        <div id="dvError" runat="server" style="display:none; padding-bottom:20px;">
            <asp:Label ID="lblError" runat="server"  ForeColor="Red"></asp:Label>
        </div>
    </center>



    <asp:TabContainer runat="server" ActiveTabIndex="0" ScrollBars="Both" ID="TabSearch" Width="100%" CssClass="fancy fancy-green">

        <asp:TabPanel ID="TabPanel1" runat="server" HeaderText="Process Order" CssClass="panel" TabIndex="1">
            <HeaderTemplate>
                <div class="divTab">Upload And Download</div>
            </HeaderTemplate>
            <ContentTemplate>
                <table id="Table1" class="table" runat="server">
                    <tr>
                        <td width="120px"><b>Date : </b></td>
                        <td width="180px">
                            <asp:TextBox ID="txtDate" runat="server" Width="200px" placeholder="dd-MMM-yyyy"></asp:TextBox>
                            <%--<asp:TextBox ID="txtFromOrder" runat="server" placeholder="01-Jan-2016" Width="100px" ReadOnly="true" onblur="ValidateDate();"></asp:TextBox>--%>
                            <asp:ImageButton ID="ImageButton2" ImageUrl="../Images/calender.png" Width="20px" Height="25px" ImageAlign="AbsMiddle" runat="server" />
                            <asp:CalendarExtender ID="CalendarExtender2" runat="server" TargetControlID="txtDate" PopupButtonID="ImageButton2" SkinID="we" Format="dd-MMM-yyyy" OnClientDateSelectionChanged="Cleardropdown"></asp:CalendarExtender>
                        </td>
                        <td>
                            <asp:RequiredFieldValidator ID="RequiredFieldValidator" runat="server" ControlToValidate="txtDate" Style="color: Red;"
                                ErrorMessage="Please select date." SetFocusOnError="true" ValidationGroup="Search" Font-Size="12px" Display="Dynamic"></asp:RequiredFieldValidator>
                            <asp:RegularExpressionValidator ValidationGroup="Search" ID="RegularExpressionValidator4"
                                ValidationExpression="^(([0-9])|([0-2][0-9])|([3][0-1]))\-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\-\d{4}$"
                                ControlToValidate="txtDate" ForeColor="Red" runat="server" Display="Dynamic" SetFocusOnError="true"
                                ErrorMessage="Please insert valid date."></asp:RegularExpressionValidator>
                        </td>
                    </tr>
                    <tr>
                        <td width="120px"><b>Project # : </b></td>
                        <td width="200px">
                            <asp:DropDownList ID="drpProjectPM" runat="server" Width="200px" Height="25px" OnSelectedIndexChanged="drpProjectPM_SelectedIndexChanged" AutoPostBack="true"></asp:DropDownList>
                        </td>
                        <td>
                            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="drpProjectPM" ValidationGroup="Search"
                                Display="Dynamic" ErrorMessage="Please Select Project." SetFocusOnError="true" ForeColor="Red" Font-Size="11px"
                                InitialValue="Select"></asp:RequiredFieldValidator>
                        </td>
                    </tr>
                    
                    <tr>
                        <td width="120px"><b>Order : </b></td>
                        <td width="200px">
                            <asp:DropDownList ID="drpOrder" runat="server" Width="200px" Height="25px" OnSelectedIndexChanged="drpOrder_SelectedIndexChanged" AutoPostBack="true"></asp:DropDownList>
                        </td>
                        <td>
                            <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ControlToValidate="drpOrder" ValidationGroup="Search"
                                Display="Dynamic" ErrorMessage="Please Select Order." SetFocusOnError="true" ForeColor="Red" Font-Size="11px"
                                InitialValue="Select"></asp:RequiredFieldValidator>
                        </td>
                    </tr>
                    <tr>
                        <td width="120px"><b>Process : </b></td>
                        <td width="200px">
                            <asp:DropDownList ID="drpProcess" runat="server" Width="200px" Height="25px" OnSelectedIndexChanged="drpProcess_SelectedIndexChanged" AutoPostBack="true"></asp:DropDownList>
                        </td>
                        <td></td>
                    </tr>

                    <tr>
                        <td style="width: 100px;"><b>Attachment :</b></td>
                        <td width="120px">
                            <asp:FileUpload runat="server" ID="fldFileAttach" /></td>
                        <td>
                            <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ValidationGroup="Search" Display="Dynamic" ControlToValidate="fldFileAttach" SetFocusOnError="True" ErrorMessage="File Required!" ForeColor="Red" Font-Size="11px"> </asp:RequiredFieldValidator></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <asp:Button ID="btnSearch" ValidationGroup="Search" runat="server" Text="Complete Process" Style="font-weight: bold; font-size: 14px; padding: 5px 10px;" OnClick="btnSearch_Click" />
                        </td>
                        <td></td>
                    </tr>
                </table>
                <div style="overflow: auto;">
                    <dx:ASPxGridView ID="grdSearch" runat="server" AutoGenerateColumns="False" ClientInstanceName="grid" EnableRowsCache="False" KeyFieldName="OrderId" Theme="Office2010Silver"
                        OnCustomCallback="grdSearch_CustomCallback" OnCustomUnboundColumnData="grdSearch_CustomUnboundColumnData" OnHtmlRowPrepared="grdSearch_HtmlRowPrepared">
                        <%--<Settings ShowFilterRow="true" ShowFilterRowMenu="true" 
                            VerticalScrollableHeight="500" />--%>

                        <%--<Settings HorizontalScrollBarMode="Auto" />--%>
                        <Columns>
                            <dx:GridViewDataTextColumn FieldName="OrderId" Caption="OrderId" Visible="False" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                            <dx:GridViewDataTextColumn FieldName="Number" VisibleIndex="0" Caption="Sr. #" Width="70px" UnboundType="String" ReadOnly="True" ShowInCustomizationForm="True" CellStyle-HorizontalAlign="Center" CellStyle-ForeColor="Black" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                            <dx:GridViewDataTextColumn FieldName="ProjectNumber" Caption="Project #" ShowInCustomizationForm="True" CellStyle-HorizontalAlign="Center" CellStyle-ForeColor="Black" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                            <dx:GridViewDataTextColumn FieldName="ClientOrderNo" Caption="Order No" ShowInCustomizationForm="True" CellStyle-HorizontalAlign="Center" CellStyle-ForeColor="Black" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                            <dx:GridViewDataTextColumn FieldName="ProcessName" Caption="Process" ShowInCustomizationForm="True" CellStyle-HorizontalAlign="Center" CellStyle-ForeColor="Black" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                            <%--<dx:GridViewDataTextColumn FieldName="Attachment" Caption="Attachment" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>--%>
                            <dx:GridViewDataColumn Caption="Attached Document" FieldName="Path" CellStyle-ForeColor="Blue" CellStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true">
                                <DataItemTemplate>
                                    <asp:LinkButton OnClick="lnkAttachment_Click" ID="lnkAttachment" Text='<%# Eval("Path")%>' runat="server"></asp:LinkButton>
                                </DataItemTemplate>
                                <CellStyle ForeColor="Blue"></CellStyle>
                            </dx:GridViewDataColumn>
                            <dx:GridViewDataTextColumn FieldName="AddedByName" Caption="Added By" CellStyle-HorizontalAlign="Center" CellStyle-ForeColor="Black" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                            <dx:GridViewDataTextColumn FieldName="AddedDate" Caption="Added Date" CellStyle-HorizontalAlign="Center" CellStyle-ForeColor="Black" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true"></dx:GridViewDataTextColumn>
                        </Columns>
                    </dx:ASPxGridView>
                </div>
            </ContentTemplate>
        </asp:TabPanel>


    </asp:TabContainer>


</div>
