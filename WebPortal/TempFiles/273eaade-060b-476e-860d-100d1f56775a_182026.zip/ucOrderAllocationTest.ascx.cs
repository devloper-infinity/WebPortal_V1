using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using DevExpress.Web;
using System.IO;
using System.Data.OleDb;
using System.Text;

public partial class ucOrderAllocationTest : System.Web.UI.UserControl
{
    protected ClientScriptManager ClientScript { get { return Page.ClientScript; } }

    bllOST bllost = new bllOST();
    bllMaster bllmaster = new bllMaster();
    bll_SendMail bllSendMail = new bll_SendMail();
    InsertOSTtask InsertOSTtask = new InsertOSTtask();
    int Beforecount = 0;
    int Aftercount = 0;
    static int TaskProcessid;
    static int ProjectNumber;
    protected void Page_Load(object sender, EventArgs e)
    {
        BACK.Style.Add("display", "none");

        TaskProcessid = Convert.ToInt32(Request.QueryString["TaskProcessid"]);
        ProjectNumber = Convert.ToInt32(Request.QueryString["ProjectNumber"]);
        if (!IsPostBack)
        {
            BindProject(drpProjectPM);
            if (drpProjectPM.SelectedIndex > 0 && drpProcess.SelectedIndex > 0)
                GetAllProcess(Convert.ToInt32(drpProjectPM.SelectedValue), drpProcess);
            BindUsersOnUserType();
            lblAutoRefMsg.Text = "Note:Page will auto refresh after every 5 minutes";
            GetAllProcesswiseOrder_Summary();
        }
    }

 
    public void GetAllProcess(int ProjectID, DropDownList ddlProcess)
    {
        try
        {
            DataTable dt = new DataTable();
            //Get Processes according to project template
            dt = bllost.GetAllProcessOnProjectTemplate(Convert.ToInt32(ProjectID));
            if (dt.Rows.Count == 0)
            {
                dt = bllost.GetAllProcess();
                ViewState["TemplateID"] = 0;
            }

            if (dt.Rows.Count > 0)
            {
                ddlProcess.DataSource = dt;
                ddlProcess.DataTextField = "ProcessName";
                ddlProcess.DataValueField = "Processid";
                ddlProcess.DataBind();
                ddlProcess.Items.Insert(0, new ListItem("Select"));
                ViewState["TemplateID"] = dt.Rows[0]["TemplateId"];
            }


            //    drpProcessA.DataSource = dt;
            //    drpProcessA.DataTextField = "ProcessName";
            //    drpProcessA.DataValueField = "Processid";
            //    drpProcessA.DataBind();
            //}
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
  
    public void GetAllOrderbyProcessNew()
    {
        try
        {
            if (drpProjectPM.SelectedIndex > 0 && drpProcess.SelectedIndex > 0)
            {
                string prevProcessId = string.Empty;
                int previousIndex = drpProcess.SelectedIndex - 1;

                if (previousIndex <= 0)
                {
                    prevProcessId = "-1";
                }
                else
                {
                    prevProcessId = drpProcess.Items[previousIndex].Value;
                }
                DataTable dt = bllost.GetAllProcesswiseOrderForAllocationNew(Convert.ToInt32(drpProcess.SelectedValue),
                                                                          int.Parse(HttpContext.Current.User.Identity.Name.ToString()),
                                                                          Convert.ToString(drpProjectPM.SelectedItem.Text),
                                                                          Convert.ToInt32(prevProcessId), Convert.ToString(Session["ProductType"]), Convert.ToString(Session["OrderDate"]));
                if (dt.Rows.Count > 0)
                {
                    grdProject.DataSource = dt;
                    grdProject.DataBind();
                }
                else
                {
                    grdProject.DataSource = null;
                    grdProject.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void LinkButton_Click(object sender, EventArgs e)
    {
        Session["Active"] = "1";
        Response.Redirect("OrderAllocation.aspx");
    }
    protected void drpQueueProcess_SelectedIndexChanged(object sender, EventArgs e)
    {
        HideError();
    }
    protected void HideError()
    {
        lblError.Text = string.Empty;
    }
    const String CallbackArgumentFormat = "function (s, e) {{ cb.PerformCallback(\"{0}|{1}|\" + {2}); }}"; // key | field | value
    protected void btnPMAllocate_Click(object sender, EventArgs e)
    {
        bool chkFlag=false;
            try
            {
                bool AtleastOneCheckboxChecked = false;
                int returnvalue1;
                returnvalue1 = 0;
                if (ddlAllocateToPerson.SelectedIndex > 0)
                {
                    for (int i = 0; i < grdProject.Rows.Count; i++)
                    {
                        int AddedBy = int.Parse(HttpContext.Current.User.Identity.Name.ToString());
                        CheckBox chk = (CheckBox)grdProject.Rows[i].FindControl("chkRow");
                        if (chk.Checked)
                        {
                            AtleastOneCheckboxChecked = true;
                            string Project = Convert.ToString(grdProject.Rows[i].Cells[2].Text);
                            string Product = Convert.ToString(grdProject.Rows[i].Cells[6].Text);
                            int OrderID = Convert.ToInt32(grdProject.DataKeys[i].Value.ToString());
                            int DocId = 0;
                            int AssignTo = Convert.ToInt32(ddlAllocateToPerson.SelectedValue);
                            int TaskProcessId = Convert.ToInt32(drpProcess.SelectedValue);
                            string AllocateTo = ddlAllocateTo.SelectedValue.ToString();

                            int returnvalue;
                            returnvalue = InsertOSTtask.InsertOstTask(OrderID, Product, Convert.ToInt32(ViewState["TemplateID"]), TaskProcessId, "Online", DocId, AssignTo, AllocateTo);
                            if (returnvalue <= 0)
                            {
                                chkFlag = true;
                                break;
                            }
                            returnvalue1 = returnvalue1 + 1;

                            #region Add Comment
                            string Comment = "Order Allocated by PM";
                            new InsertOSTtask().InsertComment(OrderID, 0, "Auto", Comment, AddedBy);
                            #endregion
                        }
                    }
                  
                    HideError();
                    if (!AtleastOneCheckboxChecked)
                    {
                        dvError.Style.Add("display", "");
                        lblError.Text = "Please Select atleast one Order!";
                        lblError.ForeColor = Color.Red;
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                    }
                    else if (returnvalue1 > 0)
                    {
                        dvError.Style.Add("display", "block");
                        lblError.Text = "Order Allocated Successfully by PM!";
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                        lblError.ForeColor = Color.Green;
                    }
                    else
                    {
                        dvError.Style.Add("display", "block");
                        lblError.Text = "Unable Allocated order!";
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                        lblError.ForeColor = Color.Green;
                    }
                }

                GetAllOrderbyProcessNew();
                GetAllProcesswiseOrder_Summary();
                BindUsersOnUserType();
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

      
        if(chkFlag==true)
        {
            chkFlag = false;
            dvError.Style.Add("display", "");
            lblError.Text = "Order has already allocated or One or more Order currently In-Process on User login......!!! ";
            lblError.ForeColor = Color.Red;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
            btnHidden_Click(sender, e);
        }
    }
    protected void ddlAllocateTo_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindUsersOnUserType();
        btnHidden_Click(sender, e);
    }
    public void BindUsersOnUserType()
    {
        try
        {
            ddlAllocateToPerson.Items.Clear();
            DataTable dtgrd = new DataTable();
            dtgrd = bllost.GetUsersOnUserType(ddlAllocateTo.SelectedValue);
            if (dtgrd.Rows.Count > 0)
            {
                for (int i = 0; i < dtgrd.Rows.Count; i++)
                {
                    ddlAllocateToPerson.Items.Add(new ListItem(Convert.ToString(dtgrd.Rows[i]["Code"]) + " : " + Convert.ToString(dtgrd.Rows[i]["FirstName"]) + " " + Convert.ToString(dtgrd.Rows[i]["MiddleName"]) + " " + Convert.ToString(dtgrd.Rows[i]["lastName"]), Convert.ToString(dtgrd.Rows[i]["EmployeeID"])));
                }
            }

            ddlAllocateToPerson.Items.Insert(0, new ListItem("Select"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void drpProjectPM_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetAllProcess(Convert.ToInt32(drpProjectPM.SelectedValue), drpProcess);
        HideError();
    }
    public void BindProject(DropDownList drpProject)
    {
        try
        {
            DataTable dt = bllost.GetAllProject(int.Parse(HttpContext.Current.User.Identity.Name.ToString()));
            drpProject.DataSource = dt;
            drpProject.DataTextField = "ProjectName";
            drpProject.DataValueField = "ProjectID";
            drpProject.DataBind();
            drpProject.Items.Insert(0, new ListItem("Select"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    #region Manual Allocation
    public void GetAllProcesswiseOrder_Summary()
    {
        if (drpProjectPM.SelectedIndex > 0 && drpProcess.SelectedIndex > 0)
        {
            int TaskProcessid = Convert.ToInt32(Session["TaskProcessid"]);
            int ProjectNumber = Convert.ToInt32(Session["ProjectNumber"]);
            int prevProcessId = Convert.ToInt32(Session["prevProcessId"]);
            int previousIndex = drpProcess.SelectedIndex - 1;

            if (previousIndex <= 0)
            {
                prevProcessId = -1;
            }
            else
            {
                prevProcessId = Convert.ToInt32(drpProcess.Items[previousIndex].Value);
            }
            grdPendingOrder.DataSource = bllost.GetAllProcesswiseOrder_Summary(Convert.ToInt32(drpProcess.SelectedValue),
                                                                       int.Parse(HttpContext.Current.User.Identity.Name.ToString()),
                                                                       Convert.ToString(drpProjectPM.SelectedItem.Text),
                                                                       Convert.ToInt32(prevProcessId));

            grdPendingOrder.DataBind();
        }
    }
    protected void drpProcess_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            string prevProcessId = string.Empty;
            int previousIndex = drpProcess.SelectedIndex - 1;

            if (previousIndex <= 0)
            {
                prevProcessId = "-1";
            }
            else
            {
                prevProcessId = drpProcess.Items[previousIndex].Value;
            }


            DataTable dt = bllost.GetAllProcesswiseOrder_Summary(Convert.ToInt32(drpProcess.SelectedValue),
                                                                      int.Parse(HttpContext.Current.User.Identity.Name.ToString()),
                                                                      Convert.ToString(drpProjectPM.SelectedItem.Text),
                                                                      Convert.ToInt32(prevProcessId));
            if (dt.Rows.Count > 0)
            {
                grdPendingOrder.DataSource = dt;
                grdPendingOrder.DataBind();
            }
            else
            {
                grdPendingOrder.DataSource = null;
                grdPendingOrder.DataBind();
            }
            grdProject.DataSource = null;
            grdProject.DataBind();

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
   
    protected void grdVendorDetails_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
    {
        int index = -1;
        if (int.TryParse(e.Parameters, out index))
            grdVendorDetails.SettingsEditing.Mode = (GridViewEditingMode)index;
    }
    protected void grdVendorDetails_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }
    #endregion
   
    protected void btnHidden_Click(object sender, EventArgs e)
    {
        string prevProcessId = string.Empty;
        int previousIndex = drpProcess.SelectedIndex - 1;

        if (previousIndex <= 0)
        {
            prevProcessId = "-1";
        }
        else
        {
            prevProcessId = drpProcess.Items[previousIndex].Value;
        }

        txtDate.Text = Convert.ToString(Session["OrderDate"]);
        if (drpProjectPM.SelectedValue != "Select")
        {

            if (drpProcess.SelectedValue != "Select")
            {
                grdPendingOrder.DataSource = bllost.GetAllProcesswiseOrder_Summary(Convert.ToInt32(drpProcess.SelectedValue),
                                                                             int.Parse(HttpContext.Current.User.Identity.Name.ToString()),
                                                                             Convert.ToString(drpProjectPM.SelectedItem),
                                                                             Convert.ToInt32(prevProcessId));
                grdPendingOrder.DataBind();
            }
        }
        GetAllOrderbyProcessNew();
        //Session["BeforeCount"] = grdProject.VisibleRowCount;
    }
   
   
   
    #region User
    public void GetAllInfinityOrderStatus()
    {
        try
        {
            DataTable dt = bllost.GetAllInfinityOrderStatus_UserWiseAllocatoin();
            if (dt.Rows.Count > 0)
            {
                grdOrderStatus.DataSource = dt;
                grdOrderStatus.DataBind();
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void grdOrderStatus_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
    {
        int index = -1;
        if (int.TryParse(e.Parameters, out index))
            grdOrderStatus.SettingsEditing.Mode = (GridViewEditingMode)index;
    }
    protected void grdOrderStatus_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }
    #endregion

   
    //protected void imgSelect_Click(object sender, ImageClickEventArgs e)
    //{
        
    //}
    protected void GrdPendingOrder1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string OrderDate = Convert.ToString(grdPendingOrder.SelectedRow.Cells[0].Text);
        string ProductType = Convert.ToString(grdPendingOrder.SelectedRow.Cells[2].Text);
        Session["OrderDate"] = OrderDate;
        Session["ProductType"] = ProductType;
        txtDate.Text = OrderDate;
        //GetAllOrderbyProcessNew();
        string prevProcessId = string.Empty;
        int previousIndex = drpProcess.SelectedIndex - 1;

        if (previousIndex <= 0)
        {
            prevProcessId = "-1";
        }
        else
        {
            prevProcessId = drpProcess.Items[previousIndex].Value;
        }
        DataTable dt = bllost.GetAllProcesswiseOrderForAllocationNew(Convert.ToInt32(drpProcess.SelectedValue),
                                                                  int.Parse(HttpContext.Current.User.Identity.Name.ToString()),
                                                                  Convert.ToString(drpProjectPM.SelectedItem.Text),
                                                                  Convert.ToInt32(prevProcessId), ProductType, OrderDate);
        if (dt.Rows.Count > 0)
        {
            grdProject.DataSource = dt;
            grdProject.DataBind();
        }
        else
        {
            grdProject.DataSource = null;
            grdProject.DataBind();
        }
    }
   
}