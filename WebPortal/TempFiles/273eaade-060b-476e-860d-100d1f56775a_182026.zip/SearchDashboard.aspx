<%@ Page Title="Search Dashboard" Language="C#" MasterPageFile="~/OST/OST.master"
    AutoEventWireup="true" CodeFile="SearchDashboard.aspx.cs" Inherits="OST_SearchDashboard"
    MaintainScrollPositionOnPostback="true" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <link href="SearchDashboard.css" rel="stylesheet" />
    <script src="SearchDashboard.js" type="text/javascript"></script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <asp:HiddenField ID="hfActiveTab" runat="server" ClientIDMode="Static" />

    <section class="search-dashboard">
        <div class="search-dashboard__header">
            <div>
                <span class="search-dashboard__eyebrow">SEARCH OPERATIONS</span>
                <h2>Search Dashboard</h2>
                <p>Order allocation, processing, document management and costing in one workspace.</p>
            </div>
        </div>

        <nav class="search-dashboard__tabs" role="tablist" aria-label="Search Dashboard modules">
            <asp:LinkButton ID="tabOrderAllocationTest" runat="server" CssClass="search-dashboard__tab"
                CommandArgument="OrderAllocationTest" OnCommand="DashboardTab_Command" CausesValidation="false">
                <span class="tab-number">01</span><span>Order Allocation Test</span>
            </asp:LinkButton>
            <asp:LinkButton ID="tabProcessOrderPM" runat="server" CssClass="search-dashboard__tab"
                CommandArgument="ProcessOrderPM" OnCommand="DashboardTab_Command" CausesValidation="false">
                <span class="tab-number">02</span><span>Process Order PM</span>
            </asp:LinkButton>
            <asp:LinkButton ID="tabUploadAndDownloadSearch" runat="server" CssClass="search-dashboard__tab"
                CommandArgument="UploadAndDownloadSearch" OnCommand="DashboardTab_Command" CausesValidation="false">
                <span class="tab-number">03</span><span>Upload And Download Search</span>
            </asp:LinkButton>
            <asp:LinkButton ID="tabEditCosting" runat="server" CssClass="search-dashboard__tab"
                CommandArgument="EditCosting" OnCommand="DashboardTab_Command" CausesValidation="false">
                <span class="tab-number">04</span><span>Edit Costing</span>
            </asp:LinkButton>
        </nav>

        <div class="search-dashboard__mobile-select">
            <label for="ddlDashboardTab">Select module</label>
            <asp:DropDownList ID="ddlDashboardTab" runat="server" ClientIDMode="Static" AutoPostBack="true"
                OnSelectedIndexChanged="ddlDashboardTab_SelectedIndexChanged" CausesValidation="false">
                <asp:ListItem Value="OrderAllocationTest">Order Allocation Test</asp:ListItem>
                <asp:ListItem Value="ProcessOrderPM">Process Order PM</asp:ListItem>
                <asp:ListItem Value="UploadAndDownloadSearch">Upload And Download Search</asp:ListItem>
                <asp:ListItem Value="EditCosting">Edit Costing</asp:ListItem>
            </asp:DropDownList>
        </div>

        <div class="search-dashboard__content" role="tabpanel">
            <asp:PlaceHolder ID="phDashboardContent" runat="server" />
        </div>
    </section>
</asp:Content>
