<%@ Control Language="C#" AutoEventWireup="true" CodeFile="ucProcessOrderPM.ascx.cs" Inherits="ucProcessOrderPM" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="asp" %>
<%@ Register Assembly="DevExpress.Web.v14.2, Version=14.2.3.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Namespace="DevExpress.Web" TagPrefix="dx" %>

<div class="search-dashboard-module search-dashboard-module--processorderpm">

    <style type="text/css">
        fieldset {
            display: block;
            -webkit-margin-start: 2px;
            -webkit-margin-end: 2px;
            -webkit-padding-before: 0.35em;
            -webkit-padding-start: 0.75em;
            -webkit-padding-end: 0.75em;
            -webkit-padding-after: 0.625em;
            border: 2px groove threedface;
            border-top-color: threedface;
            border-top-style: groove;
            border-top-width: 2px;
            border-image-source: initial;
            border-image-slice: initial;
            border-image-width: initial;
            border-image-outset: initial;
            border-image-repeat: initial;
            min-width: -webkit-min-content;
        }

        legend {
            display: block;
            -webkit-padding-start: 2px;
            -webkit-padding-end: 2px;
            border: none;
            /*border-top-style: none;*/
            border-image-source: initial;
            border-image-slice: initial;
            border-image-width: initial;
            border-image-outset: initial;
            border-image-repeat: initial;
        }

        dxgvHeader_Office2010Silver td th {
            padding: 5px,0px;
        }
    </style>

    
    
    <script type="text/javascript">

        function GetCountryDetails() {
            var parm = document.getElementById("<%= drpStatus.ClientID %>");
            var strCountry = parm.options[parm.selectedIndex].text;
            if (strCountry == "Transfer") {
                drpCaller.display = true;
            }
        }

        function CheckCheckboxes() {

            var chkdispatch = document.getElementById("<%= chkDispatch.ClientID%>");
            var chkcancel = document.getElementById("<%= chkCancel.ClientID%>");
            var chkhold = document.getElementById("<%= chkHold.ClientID%>");

            var cancelledBy = document.getElementById("<%= cancelledBy.ClientID%>");
            var reason = document.getElementById("<%= reason.ClientID%>");

            var lblRemarkError = document.getElementById("<%= lblRemarkError.ClientID%>");
            var lblReasonError = document.getElementById("<%= lblReasonError.ClientID%>");

            if (chkdispatch.checked == true) {
                chkcancel.checked = false;
                chkhold.checked = false;
                cancelledBy.style.display = "none";
                reason.style.display = "none";

                lblRemarkError.innerHTML = "";
                lblReasonError.innerHTML = "";
            }
            if (chkcancel.checked == true) {
                chkdispatch.checked = false;
                chkhold.checked = false;
                cancelledBy.style.display = "table-row";
                reason.style.display = "table-row";
            }

            if (chkcancel.checked == false) {

                cancelledBy.style.display = "none";
                reason.style.display = "none";
            }

            if (chkhold.checked == true) {
                chkdispatch.checked = false;
                chkcancel.checked = false;
                cancelledBy.style.display = "none";
                reason.style.display = "none";
            }
        }

        function Confirm() {

            var chkdispatch = document.getElementById("<%= chkDispatch.ClientID%>");
            var ddlOrderNo = document.getElementById("<%= ddlOrderNo.ClientID%>");
            var selectedIndex = ddlOrderNo.selectedIndex;
            var txtTaskRemark = document.getElementById("<%= txtTaskRemark.ClientID%>");
            var txtReason = document.getElementById("<%= txtReason.ClientID%>");
            var lblRemarkError = document.getElementById("<%= lblRemarkError.ClientID%>");
            var lblReasonError = document.getElementById("<%= lblReasonError.ClientID%>");

            if (chkdispatch.checked == true && selectedIndex > 0) {

                var confirm_value = document.createElement("INPUT");
                confirm_value.type = "hidden";
                confirm_value.name = "confirm_value";
                if (confirm("Do you want to dispatch Order?")) {
                    confirm_value.value = "Yes";
                } else {
                    confirm_value.value = "No";
                }
                document.forms[0].appendChild(confirm_value);
            }

            var chkCancel = document.getElementById("<%= chkCancel.ClientID%>");

            if (chkCancel.checked == true && selectedIndex > 0) {
                if (txtTaskRemark.value == "") {
                    lblRemarkError.innerHTML = "Please Enter Remark";
                    return false;
                }
                if (txtReason.value == "") {
                    lblReasonError.innerHTML = "Please Enter Reason";
                    return false;
                }

                else {

                    lblRemarkError.innerHTML = "";
                    lblReasonError.innerHTML = "";
                    var confirmCancel_value = document.createElement("INPUT");
                    confirmCancel_value.type = "hidden";
                    confirmCancel_value.name = "confirmCancel_value";
                    if (confirm("Do you want to Cancel Order?")) {
                        confirmCancel_value.value = "Yes";
                    } else {
                        confirmCancel_value.value = "No";
                    }
                    document.forms[0].appendChild(confirmCancel_value);
                }
            }

            var chkHold = document.getElementById("<%= chkHold.ClientID%>");
            if (chkHold.checked == true && selectedIndex > 0) {

                if (txtTaskRemark.value == "") {
                    lblRemarkError.innerHTML = "Please Enter Remark";
                    return false;
                }
                else {

                    lblRemarkError.text = "";
                    var confirmHold_value = document.createElement("INPUT");
                    confirmHold_value.type = "hidden";
                    confirmHold_value.name = "confirmHold_value";
                    if (confirm("Do you want to Hold Order?")) {
                        confirmHold_value.value = "Yes";
                    } else {
                        confirmHold_value.value = "No";
                    }
                    document.forms[0].appendChild(confirmHold_value);
                }
            }
        }

        function OnMoreInfoClick(element, key) {
            callbackPanel.SetContentHtml("");
            popup.ShowAtElement(element);
            keyValue = key;
        }
        function popup_Shown(s, e) {
            callbackPanel.PerformCallback(keyValue);
        }

        var keyValue;
        function OnMoreInfoClickS(element) {
            callbackPanel1.SetContentHtml("");
            popupD.ShowAtElement(element);
            var ddlOrderNo = document.getElementById("<%= ddlOrderNo.ClientID%>");
            var key = (ddlOrderNo.selectedIndex).value;
            keyValue = key;
        }
        function popupD_Shown(s, e) {
            callbackPanel1.PerformCallback(keyValue);
        }

        function HideLabel() {
            var seconds = 5;
            setTimeout(function () {
                document.getElementById("<%=dvError.ClientID %>").style.display = "none";
            }, seconds * 1000);
        };

        function onSelectAll(s, e) {
            $(
    '[id*="CheckBox1"]').each(function () {
        try {
            eval($(this)[0].id).SetChecked(s.GetChecked());
        }

        catch (err) { }
    });

            return false;
        }

        function txtTaskRemark_Change() {

            var chkHold = document.getElementById("<%= chkHold.ClientID%>");
            var chkCancel = document.getElementById("<%= chkCancel.ClientID%>");
            var ddlOrderNo = document.getElementById("<%= ddlOrderNo.ClientID%>");
            var selectedIndex = ddlOrderNo.selectedIndex;
            var txtTaskRemark = document.getElementById("<%= txtTaskRemark.ClientID%>");
            var lblRemarkError = document.getElementById("<%= lblRemarkError.ClientID%>");

            if ((chkHold.checked == true || chkCancel.checked == true) && selectedIndex > 0) {
                if (txtTaskRemark.value == "") {
                    lblRemarkError.innerHTML = "Please Enter Remark";
                }
                else {
                    lblRemarkError.innerHTML = "";
                }
            }
        }

        function txtReason_Change() {

            var chkCancel = document.getElementById("<%= chkCancel.ClientID%>");
            var ddlOrderNo = document.getElementById("<%= ddlOrderNo.ClientID%>");
            var selectedIndex = ddlOrderNo.selectedIndex;
            var txtReason = document.getElementById("<%= txtReason.ClientID%>");
            var lblReasonError = document.getElementById("<%= lblReasonError.ClientID%>");

            if (chkCancel.checked == true && selectedIndex > 0) {
                if (txtReason.value == "") {
                    lblReasonError.innerHTML = "Please Enter Remark";
                }
                else {
                    lblReasonError.innerHTML = "";
                }
            }
        }

        function ValidateRemark(oSrc, args) {

            var ddlOrderNo = document.getElementById("<%= ddlOrderNo.ClientID%>");
            var chkhold = document.getElementById("<%= chkHold.ClientID%>");
            var chkcancel = document.getElementById("<%= chkCancel.ClientID%>");
            var chkdispatch = document.getElementById("<%= chkDispatch.ClientID%>");
            var txtTaskRemark = document.getElementById("<%= txtTaskRemark.ClientID%>");
            var selectedIndex = ddlOrderNo.selectedIndex;

            if ((chkcancel.checked == true || chkhold.checked == true) && selectedIndex > 0) {
                if (txtTaskRemark.value == "") {
                    args.IsValid = false;
                }
                else {
                    args.IsValid = true;
                }
            }

            if (chkdispatch.checked == true) {
                args.IsValid = true;
            }


        }

        function ValidateReason(oSrc, args) {
            var ddlOrderNo = document.getElementById("<%= ddlOrderNo.ClientID%>");
            var chkcancel = document.getElementById("<%= chkCancel.ClientID%>");
            var txtReason = document.getElementById("<%= txtReason.ClientID%>");
            var selectedIndex = ddlOrderNo.selectedIndex;

            if (chkcancel.checked == true && selectedIndex > 0) {
                if (txtReason.value == "") {
                    args.IsValid = false;
                }
                else {
                    args.IsValid = true;
                }
            }

            if (chkdispatch.checked == true) {
                args.IsValid = true;
            }
        }





    </script>


    <center>
        <div id="dvError" runat="server" style="display:none; padding-bottom:20px;">
            <asp:Label ID="lblError" runat="server"  ForeColor="Red"></asp:Label>
        </div>
    </center>

    <dx:ASPxPopupControl ID="popupD" ClientInstanceName="popupD" runat="server" AllowDragging="true"
        PopupHorizontalAlign="WindowCenter" HeaderText="Order Details" PopupVerticalAlign="WindowCenter">
        <HeaderStyle Font-Bold="true" />
        <ContentCollection>
            <dx:PopupControlContentControl ID="PopupControlContentControl2" runat="server">
                <dx:ASPxCallbackPanel ID="callbackPanel1" ClientInstanceName="callbackPanel1" runat="server"
                    Width="650px" Height="200px" RenderMode="Table">
                    <PanelCollection>
                        <dx:PanelContent ID="pnlViewOrderdetails" runat="server">
                            <asp:Label ID="lblDetails" runat="server" Style="color: red;"></asp:Label>
                            <dx:ASPxGridView ID="grdOrderReportDetails" runat="server" AutoGenerateColumns="false"
                                EnableRowsCache="False" KeyFieldName="OrderID" ShownEditor="grdVendor_ShownEditor"
                                OnCustomUnboundColumnData="grdOrderReportDetails_CustomUnboundColumnData"
                                OnHtmlRowPrepared="grdOrderReportDetails_HtmlRowPrepared"
                                CustomDrawCell="grdVendor_CustomDrawCell" Theme="Office2010Silver" Width="100%">
                                <Columns>
                                    <dx:GridViewDataTextColumn FieldName="Number" VisibleIndex="0" Caption="Sr. #" Width="70px" UnboundType="String" ReadOnly="True" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="ClientOrderNo" Caption="Order No"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="Process" Caption="Process Name"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="OrderPriority" Caption="OrderPriority"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="Remark" Caption="Remark"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataColumn Caption="AttachedDocument" FieldName="Path" CellStyle-ForeColor="Blue">
                                        <DataItemTemplate>
                                            <asp:LinkButton OnClick="lnkAttachment_Click" ID="lnkAttachment" Text='<%# Eval("Path")%>' runat="server"></asp:LinkButton>
                                        </DataItemTemplate>
                                    </dx:GridViewDataColumn>
                                    <dx:GridViewDataTextColumn FieldName="ClientIdNew" Caption="ClientId"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="CustomerType" Caption="CustomerType"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="LegalDescription" Caption="LegalDescription"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="Instruction" Caption="Instruction"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataColumn Caption="OrderSheet" FieldName="OrdersheetPath" CellStyle-ForeColor="Blue">
                                        <DataItemTemplate>
                                             <asp:LinkButton id="linkOrderSheet" OnClick="linkOrderSheet_Click" Text='<%# Eval("OrdersheetPath")%>' runat="server"></asp:LinkButton>
                                        </DataItemTemplate>
                                    </dx:GridViewDataColumn>
                                    <dx:GridViewDataTextColumn FieldName="AddedBy" Caption="AddedBy"></dx:GridViewDataTextColumn>
                                    <dx:GridViewDataTextColumn FieldName="AddedDate" Caption="AddedDate"></dx:GridViewDataTextColumn>

                                </Columns>
                            </dx:ASPxGridView>

                        </dx:PanelContent>
                    </PanelCollection>
                </dx:ASPxCallbackPanel>
            </dx:PopupControlContentControl>
        </ContentCollection>
        <ClientSideEvents Shown="popupD_Shown" />
    </dx:ASPxPopupControl>
    <dx:ASPxPopupControl ID="popup" ClientInstanceName="popup" runat="server" AllowDragging="true"
        PopupHorizontalAlign="WindowCenter" HeaderText="Change Status" PopupVerticalAlign="WindowCenter">
        <HeaderStyle Font-Bold="true" />
        <ContentCollection>
            <dx:PopupControlContentControl ID="PopupControlContentControl1" runat="server">
                <dx:ASPxCallbackPanel ID="callbackPanel" ClientInstanceName="callbackPanel" runat="server"
                    Width="450px" Height="200px" OnCallback="callbackPanel_Callback" RenderMode="Table">
                    <PanelCollection>
                        <dx:PanelContent ID="PanelContent1" runat="server">
                            <div id="Div1" runat="server" style="font-size: 14px;">
                                <center>
                                    <asp:Label ID="Label1" runat="server" ForeColor="Red"></asp:Label>
                                        </center>
                            </div>

                            <asp:Panel runat="server" ID="pnlPopup">

                                <table id="Table1" class="table" runat="server">
                                    <tr>
                                        <td><b>Status :</b></td>
                                        <td>
                                            <asp:DropDownList ID="drpStatus" runat="server" Width="300px" Height="25px" OnSelectedIndexChanged="drpStatus_SelectedIndexChanged" AutoPostBack="true">
                                                <asp:ListItem>Select</asp:ListItem>
                                                <asp:ListItem>Complete</asp:ListItem>
                                                <asp:ListItem>Hold</asp:ListItem>
                                                <asp:ListItem>Cancel</asp:ListItem>
                                                <asp:ListItem>Transfer</asp:ListItem>
                                            </asp:DropDownList></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td>
                                            <asp:DropDownList ID="drpCaller" runat="server" Width="300px" Height="25px" Visible="false"></asp:DropDownList></td>
                                    </tr>
                                    <tr>
                                        <td><b>Attachment :</b></td>
                                        <td>
                                            <asp:FileUpload runat="server" ID="fldAttachment" /></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td>
                                            <asp:Button ID="btnSave" runat="server" Text="Submit" Style="font-weight: bold; font-size: 14px; padding: 5px 10px;" OnClick="btnSave_Click" /></td>
                                    </tr>
                                </table>

                            </asp:Panel>
                        </dx:PanelContent>
                    </PanelCollection>
                </dx:ASPxCallbackPanel>
            </dx:PopupControlContentControl>
        </ContentCollection>
        <ClientSideEvents Shown="popup_Shown" />
    </dx:ASPxPopupControl>

    <div class="container">

        <div class="col-sm-12">
            <div class="panel panel-grape">
               
                <div class="panel-body">
                    <div class="table">
                        <table class="table1">
                            <%--<tr style="visibility:hidden">
                                <td><b>Order : <span style="color: red;">*</span></b></td>
                                <td>
                                    <asp:DropDownList ID="drpOrder" runat="server" Width="300px" Height="25px" AutoPostBack="true" OnSelectedIndexChanged="drpOrder_SelectedIndexChanged"></asp:DropDownList>
                                </td>
                                <td>
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="drpOrder" ValidationGroup="Reg1"
                                        Display="Dynamic" ErrorMessage="Please Select Order" SetFocusOnError="True" ForeColor="Red" Font-Size="11px"
                                        InitialValue="Select"></asp:RequiredFieldValidator>
                                </td>
                            </tr>--%>
                            <tr>
                                <td><b>Project # : <span style="color: red;">*</span></b></td>
                                <td>
                                    <asp:DropDownList ID="drpProject" runat="server" Width="300px" Height="25px" OnSelectedIndexChanged="drpProject_SelectedIndexChanged" AutoPostBack="true"></asp:DropDownList>
                                </td>
                                <td>
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" ControlToValidate="drpProject" ValidationGroup="Reg1"
                                        Display="Dynamic" ErrorMessage="Please Select Project" SetFocusOnError="true" ForeColor="Red" Font-Size="11px"
                                        InitialValue="Select"></asp:RequiredFieldValidator>
                                </td>
                            </tr>
                            <tr>
                                <td><b>Order No : <span style="color: red;">*</span></b></td>
                                <td>
                                    <asp:DropDownList ID="ddlOrderNo" runat="server" Width="300px" Height="25px" OnSelectedIndexChanged="ddlOrderNo_SelectedIndexChanged" AutoPostBack="true" IncrementalFilteringMode="Contains"></asp:DropDownList>
                                </td>
                                <td>
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ControlToValidate="ddlOrderNo" ValidationGroup="Reg1"
                                        Display="Dynamic" ErrorMessage="Please Select Order" SetFocusOnError="True" ForeColor="Red" Font-Size="11px"
                                        InitialValue="Select"></asp:RequiredFieldValidator>
                                </td>
                            </tr>
                            <tr>
                                <td><b>Process : </b></td>
                                <td>
                                    <asp:DropDownList ID="drpProcess" runat="server" Width="300px" Height="25px" Enabled="False">
                                    </asp:DropDownList></td>
                            </tr>
                            <tr>
                                <td>
                                    <b>User : </b>
                                </td>
                                <td>
                                    <asp:DropDownList runat="server" Enabled="false" ID="ddlUser" Width="300px" Height="25px"></asp:DropDownList>
                                </td>
                            </tr>
                            <tr>
                                <td><b>Attachment :</b></td>
                                <td>
                                    <asp:FileUpload runat="server" ID="fldFileAttach" /></td>
                                <td>
                                    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ValidationGroup="Reg1" Display="Dynamic" ControlToValidate="fldFileAttach" SetFocusOnError="True" ErrorMessage="File Required!" ForeColor="Red" Font-Size="11px"> </asp:RequiredFieldValidator></td>
                            </tr>
                            <tr>
                                <td>
                                    <b>Remark :</b>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtTaskRemark" Height="70px" runat="server" TextMode="MultiLine" Width="300px" onkeypress="txtTaskRemark_Change()"></asp:TextBox>
                                </td>
                                <td>
                                    <a href="javascript:void(0);" id="lnkViewDetails" runat="server" onclick="OnMoreInfoClickS(this)">View Details   </a>

                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <asp:Label ID="lblRemarkError" runat="server" ForeColor="Red"></asp:Label>
                                    <%--  <asp:CustomValidator id="remarkValidator" runat="server"  ErrorMessage="Please Enter Remark" Display="Dynamic"
                                                 ValidationGroup="Reg1" ForeColor="Red" ValidateEmptyText="true" ControlToValidate="txtTaskRemark"
                                                ClientValidationFunction="ValidateRemark" />--%>  
                                </td>
                            </tr>
                            <tr id="cancelledBy" runat="server">
                                <td style="font-weight: bold;">Cancelled By :
                                </td>
                                <td>
                                    <asp:DropDownList ID="ddlApprove" runat="server">
                                        <asp:ListItem>Cancelled by Client</asp:ListItem>
                                        <asp:ListItem>Cancelled by Infinity</asp:ListItem>
                                    </asp:DropDownList>
                                </td>

                            </tr>
                            <tr id="reason" runat="server">
                                <td style="font-weight: bold;">Reason :
                                </td>
                                <td>
                                    <asp:TextBox ID="txtReason" runat="server" TextMode="MultiLine" Width="300px" Height="80px" onkeypress="txtReason_Change()"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                                    <asp:Label ID="lblReasonError" runat="server" ForeColor="Red"></asp:Label>
                                    <%-- <asp:CustomValidator id="reasonValidator" runat="server"  ErrorMessage="Please Enter Reason" Display="Dynamic"
                                                 ValidationGroup="Reg1"
                                                ClientValidationFunction="ValidateReason"  ForeColor="Red" ValidateEmptyText="true" ControlToValidate="txtReason" />  --%>                                   
                                </td>
                            </tr>

                            <tr>
                                <td></td>
                                <td>
                                    <asp:CheckBox ID="chkDispatch" runat="server" Text="Dispatch Order" onclick="CheckCheckboxes()" />

                                    <asp:CheckBox ID="chkCancel" runat="server" Text="Cancel Order" onclick="CheckCheckboxes()" />

                                    <asp:CheckBox ID="chkHold" runat="server" Text="Hold Order" onclick="CheckCheckboxes()" />

                                    <asp:CheckBox ID="ChkNoError" runat="server" Text="No Feedback"  onclick="CheckCheckboxes()" />
                                </td>
                            </tr>

                            <tr>
                                <td></td>
                                <td>
                                    <asp:Button ID="btnSubmit" runat="server" Text="Submit" OnClientClick="return Confirm();" ValidationGroup="Reg1" Style="font-weight: bold; font-size: 14px; padding: 5px 10px;" OnClick="btnSubmit_Click" />


                                </td>
                                <td></td>
                            </tr>
                        </table>

                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-12">
            <div class="panel panel-grape">
                <div class="panel-heading">
                    <h4><i></i>
                        View Process Order</h4>
                </div>
                <div class="panel-body">
                    <div class="table">
                        <dx:ASPxGridView ID="grdProcessOrder" Width="750px" runat="server" AutoGenerateColumns="False" ClientInstanceName="grid" EnableRowsCache="False" KeyFieldName="Taskid" ShownEditor="grdVendor_ShownEditor" CustomDrawCell="grdVendor_CustomDrawCell" Theme="Office2010Silver"
                            OnCustomCallback="grdProcessOrder_CustomCallback" OnCustomUnboundColumnData="grdProcessOrder_CustomUnboundColumnData" OnCustomButtonCallback="grdProcessOrder_CustomButtonCallback" OnHtmlRowPrepared="grdProcessOrder_HtmlRowPrepared">
                            <SettingsPager Mode="ShowAllRecords"></SettingsPager>
                            <SettingsBehavior ConfirmDelete="True" />
                            <ClientSideEvents EndCallback="OnEndCallback" />
                            <Settings HorizontalScrollBarMode="Auto" />
                            <Columns>
                                <dx:GridViewDataTextColumn FieldName="Taskid" VisibleIndex="0" Width="30px" ShowInCustomizationForm="True">
                                    <Settings AllowSort="False" ShowInFilterControl="False" />
                                    <DataItemTemplate>
                                        <dx:ASPxCheckBox runat="server" ID="CheckBox1" Checked="true" CheckBoxStyle-HorizontalAlign="Center">
                                        </dx:ASPxCheckBox>
                                        <asp:Label ID="lblID" runat="server" Text='<%# Eval("Taskid")%>' Visible="false"> 
                                        </asp:Label>
                                    </DataItemTemplate>
                                    <CellStyle HorizontalAlign="Left">
                                    </CellStyle>
                                    <HeaderTemplate>
                                        <dx:ASPxCheckBox runat="server" ID="CheckBox2" Checked="true" CheckBoxStyle-HorizontalAlign="Center" ClientInstanceName="SelectAllCheckBox" ClientSideEvents-CheckedChanged="onSelectAll" AutoPostBack="false"></dx:ASPxCheckBox>
                                    </HeaderTemplate>
                                </dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="Taskid" Caption="Taskid" Visible="False" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="Number" VisibleIndex="0" Caption="Sr. #" Width="70px" UnboundType="String" ReadOnly="True" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="Orderid" Caption="Orderid" Visible="False" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="OrderDate" Caption="Order Date" ShowInCustomizationForm="True" VisibleIndex="1"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="Project" Caption="Project #" ShowInCustomizationForm="True" VisibleIndex="2"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ClientOrderNo" Caption="Order No" ShowInCustomizationForm="True" VisibleIndex="3"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="DocumentType" Caption="Document Type" VisibleIndex="4"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="InfinityOrderNo" Caption="Infinity Order #" Visible="False" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ProductType" Caption="ProductType" VisibleIndex="5"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="BName" Caption="Borrower Name" VisibleIndex="6"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="PropertyAddress" Caption="Property Address" VisibleIndex="7"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="State" Caption="State" VisibleIndex="8"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="County" Caption="County" ShowInCustomizationForm="True" VisibleIndex="9"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="Docid" Caption="Docid" Visible="False" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="TransferAssignedId" Caption="TransferAssignedId" Visible="False" ShowInCustomizationForm="True"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ProcessName" Caption="Process" ShowInCustomizationForm="True" VisibleIndex="10"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ClientIdNew" Caption="ClientId" ShowInCustomizationForm="True" VisibleIndex="11"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="CustomerType" Caption="CustomerType" ShowInCustomizationForm="True" VisibleIndex="12"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="Instruction" Caption="Instruction" ShowInCustomizationForm="True" VisibleIndex="13"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataColumn Caption="Status" VisibleIndex="14" ShowInCustomizationForm="True">
                                    <DataItemTemplate>
                                        <a href="javascript:void(0);" onclick="OnMoreInfoClick(this, '<%# Container.KeyValue %>')">Status
                                        </a>
                                    </DataItemTemplate>
                                </dx:GridViewDataColumn>
                            </Columns>
                        </dx:ASPxGridView>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
