using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using DevExpress.Web;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

public partial class ucUploadAndDownloadSearch : System.Web.UI.UserControl
{
    protected ClientScriptManager ClientScript { get { return Page.ClientScript; } }

    bllOST bllost = new bllOST();
    BLLTMM bllTMM = new BLLTMM();

    List<string> lstInstrumentNumber = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {

        // string Attachment = fldFileAttach.FileName;
        //Attachment = "images.jpg";
        lblError.Text = "";
        if (!IsPostBack)
        {
            BindProject(drpProjectPM);
            //GetAllAssignOrder();

        }      

            BindGrid();
       
    }

    public void GetAllAssignOrder()
    {
        try
        {
            string Date = txtDate.Text;
            if (drpProjectPM.SelectedIndex > 0)
            {
                DataTable dtgrd = new DataTable();
                // dtgrd = bllost.GetAllInfinityOrderbyEmpAndProject(int.Parse(HttpContext.Current.User.Identity.Name.ToString()), Convert.ToString(drpProjectPM.SelectedItem.Text));
                dtgrd = bllost.GetAllInfinityOrderbyEmpAndProject_UploadDoc(int.Parse(HttpContext.Current.User.Identity.Name.ToString()), Convert.ToString(drpProjectPM.SelectedItem.Text), Date);
                drpOrder.DataSource = dtgrd;
                drpOrder.DataTextField = "ClientOrderNo";
                drpOrder.DataValueField = "OrderID";
                drpOrder.DataBind();
                drpOrder.Items.Insert(0, new ListItem("Select"));
            }

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void BindProject(DropDownList drpProject)
    {
        try
        {
            DataTable dt = bllost.GetAllProject(int.Parse(HttpContext.Current.User.Identity.Name.ToString()));
            drpProject.DataSource = dt;
            drpProject.DataTextField = "ProjectName";
            drpProject.DataValueField = "ProjectID";
            drpProject.DataBind();
            drpProject.Items.Insert(0, new ListItem("Select"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }


    protected void drpProjectPM_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            GetAllAssignOrder();
            GetAllProcess(Convert.ToInt32(drpProjectPM.SelectedValue));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    public void GetAllProcess(int ProjectID)
    {
        try
        {
            DataTable dt = new DataTable();
            //Get Processes according to project template
            dt = bllost.GetAllProcessOnProjectTemplate(Convert.ToInt32(ProjectID));
            if (dt.Rows.Count == 0)
            {
                dt = bllost.GetAllProcess();
            }

            if (dt.Rows.Count > 0)
            {
                drpProcess.DataSource = dt;
                drpProcess.DataTextField = "ProcessName";
                drpProcess.DataValueField = "Processid";
                drpProcess.DataBind();
                drpProcess.Items.Insert(0, new ListItem("Select"));
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void drpProcess_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            BindGrid();
        }
        catch (Exception Ex)
        {
            Ex.Message.ToString();
        }
    }
    public void BindGridOrderwise()
    {
        //  DataTable dt2 = bllost.GetCurrentProcessOfUser(Convert.ToInt32(drpOrder.SelectedValue), Convert.ToInt32(HttpContext.Current.User.Identity.Name));
        DataTable dt2 = bllost.GetCurrentProcessOfUser_ForUploadDoc(Convert.ToInt32(drpOrder.SelectedValue), Convert.ToInt32(HttpContext.Current.User.Identity.Name));
        if (dt2.Rows.Count > 0)
        {
            drpProcess.DataSource = dt2;
            drpProcess.DataTextField = "ProcessName";
            drpProcess.DataValueField = "Processid";
            drpProcess.DataBind();
            //drpProcess.Items.Insert(0, new ListItem("Select"));

        }
    }
    protected void drpOrder_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (drpOrder.SelectedIndex > 0)
            {
                int OrderID = Convert.ToInt32(drpOrder.SelectedValue);

                //BindGridOrderwise();
                BindGrid();
                lblError.Text = string.Empty;
            }
            else
            {
                drpProcess.SelectedIndex = 0;

            }

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void grdSearch_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
    {
        int index = -1;
        if (int.TryParse(e.Parameters, out index))
            grdSearch.SettingsEditing.Mode = (GridViewEditingMode)index;
    }
    protected void grdSearch_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }
    public void BindGrid()
    {
        try
        {
            // string Date = txtDate.Text;
            if (drpOrder.SelectedIndex > 0)
            {
                DataTable dt = bllost.GetAllUploadAndDownloadSearch(Convert.ToString(drpOrder.SelectedValue));
                grdSearch.DataSource = dt;
                grdSearch.DataBind();
            }
        }
        catch (Exception Ex)
        {
            Ex.Message.ToString();
        }
    }
    public void Clear()
    {
        txtDate.Text = "";
        drpProjectPM.SelectedIndex = 0;
        drpOrder.SelectedIndex = -1;
        drpProcess.SelectedIndex = 0;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            if (drpProjectPM.SelectedIndex > 0)
            {
                if (drpOrder.SelectedIndex > 0)
                {
                    int AddedBy = int.Parse(HttpContext.Current.User.Identity.Name.ToString());
                    string orderNo = drpOrder.SelectedItem.Text;
                    if (fldFileAttach.FileName != "")
                    {
                        string AttachOrderNo;
                        string AttachOrderNo1;
                       
                        int indexof;

                        AttachOrderNo = fldFileAttach.FileName;
                        indexof = AttachOrderNo.LastIndexOf(".");
                        AttachOrderNo1 = AttachOrderNo.Substring(0, indexof);
                        if (orderNo.ToLower() == AttachOrderNo1.ToLower())
                        {
                            Hashtable htparam = new Hashtable();
                            htparam["ProjectNumber"] = drpProjectPM.SelectedItem.Text;
                            htparam["ClientOrderNo"] = drpOrder.SelectedItem.Text;
                            htparam["Process"] = drpProcess.SelectedItem.Text;
                            htparam["AddedBy"] = AddedBy;
                            htparam["OrderId"] = drpOrder.SelectedValue;
                            #region Code For Insert Attachment
                            string Attachment;
                            if (fldFileAttach.HasFile)
                            {

                                if (!Directory.Exists(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text)))
                                {
                                    Directory.CreateDirectory(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text));
                                }

                                if (!Directory.Exists(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy"))))
                                {
                                    Directory.CreateDirectory(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy")));
                                }

                                if (!Directory.Exists(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + drpOrder.SelectedValue)))
                                {
                                    Directory.CreateDirectory(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + drpOrder.SelectedValue));
                                }

                                fldFileAttach.SaveAs(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + drpOrder.SelectedValue + "\\" + "RevisedPackage_" + fldFileAttach.FileName));
                                Attachment = "~\\OSTAttachment\\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + drpOrder.SelectedValue + "\\" + "RevisedPackage_" + fldFileAttach.FileName;
                                string Attachment1 = Server.MapPath(@"~\\OSTAttachment\\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + drpOrder.SelectedValue + "\\" + "RevisedPackage_" + fldFileAttach.FileName);

                            }
                            else
                            {
                                Attachment = "";
                            }

                            #endregion
                            htparam["Attachment"] = Attachment;
                            if (Attachment != "")
                            {

                                new InsertOSTtask().InsertOSTAttachment(Convert.ToInt32(drpOrder.SelectedValue), Convert.ToInt32(drpProcess.SelectedValue), 0, Attachment, "Process Completed", AddedBy);

                                dvError.Style.Add("display", "");
                                lblError.Text = "Document Uploaded Successfully!";
                                lblError.Visible = true;
                                dvError.Visible = true;
                                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                                lblError.ForeColor = Color.Green;

                                BindGrid();
                                //Clear();
                            }
                            //if (ReturnValue > 0)
                            //{

                            //    dvError.Style.Add("display", "");
                            //    lblError.Text = "Document Uploaded Successfully!";
                            //    lblError.Visible = true;
                            //    dvError.Visible = true;
                            //    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                            //    lblError.ForeColor = Color.Green;

                            //    BindGrid();
                            //    Clear();
                            //}
                            //else
                            //{
                            //    dvError.Style.Add("display", "");
                            //    lblError.Text = "Error!!";
                            //    lblError.Visible = true;
                            //    dvError.Visible = true;
                            //    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                            //    lblError.ForeColor = Color.Red;
                            //}
                        }
                        else
                        {
                            dvError.Style.Add("display", "");
                            lblError.Text = "The selected file Name does not match with the Order No.";
                            lblError.Visible = true;
                            dvError.Visible = true;
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                            lblError.ForeColor = Color.Red;
                            return;
                        }
                    }
                }
            }
            else
            {
                dvError.Style.Add("display", "");
                lblError.Text = "Please Select Project.";
                lblError.Visible = true;
                dvError.Visible = true;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                lblError.ForeColor = Color.Red;
                return;
            }
        }
        catch (Exception Ex)
        {
            Ex.Message.ToString();
        }
    }
    protected void lnkAttachment_Click(object sender, EventArgs e)
    {
        string filePath = (sender as LinkButton).Text;
        Response.ContentType = ContentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
        Response.WriteFile(filePath);
        Response.End();
    }
    protected void grdSearch_HtmlRowPrepared(object sender, ASPxGridViewTableRowEventArgs e)
    {
        if (e.RowType == GridViewRowType.Data)
        {
            LinkButton lnkAttachment = (LinkButton)grdSearch.FindRowCellTemplateControl(e.VisibleIndex, null, "lnkAttachment");
            string attachmentPath = lnkAttachment.Text;
            if (!String.IsNullOrEmpty(attachmentPath))
            {
                string fileName = attachmentPath.Substring(attachmentPath.LastIndexOf("\\") + 1);
                lnkAttachment.Text = fileName;
                lnkAttachment.Style.Add("Color", "Blue");
            }

        }
    }
}




