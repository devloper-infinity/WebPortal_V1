(function () {
    "use strict";
    function markBusy() {
        var content = document.querySelector(".search-dashboard__content");
        if (content) content.classList.add("is-loading");
    }
    document.addEventListener("click", function (event) {
        var tab = event.target.closest && event.target.closest(".search-dashboard__tab");
        if (tab) markBusy();
    });
    window.addEventListener("pageshow", function () {
        var content = document.querySelector(".search-dashboard__content");
        if (content) content.classList.remove("is-loading");
    });
}());
