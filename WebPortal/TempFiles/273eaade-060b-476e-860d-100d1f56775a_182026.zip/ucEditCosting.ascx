<%@ Control Language="C#" AutoEventWireup="true" CodeFile="ucEditCosting.ascx.cs" Inherits="ucEditCosting" %>
<%@ Register Assembly="DevExpress.Web.v14.2, Version=14.2.3.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Namespace="DevExpress.Web" TagPrefix="dx" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="asp" %>

<div class="search-dashboard-module search-dashboard-module--editcosting">

    <link href="../bootstrap/css/TabContainer.css" rel="stylesheet" />


    <script>
        function ShowOrderCosting(contentUrl) {
            OrderCostingPopUp.SetContentUrl(contentUrl);
            OrderCostingPopUp.Show();
        }
    </script>
    <%--<script type="text/javascript">
        function ValidateDate() {
            var fromdate = document.getElementById("<%= txtFrom.ClientID%>");
            var todate = document.getElementById("<%= txtTo.ClientID%>");
            var endDate = todate.value;
            var startDate = fromdate.value;

            var newStartDate = Date.parse(startDate); //Parse the date to  milliseconds since January 1, 1970, 00:00:00 UTC
            var newEndDate = Date.parse(endDate);
            if (newStartDate > newEndDate) {
                document.getElementById("<%= lblDateError.ClientID%>").innerHTML = "From Date should be less than To Date.";
                document.getElementById("<%= lblDateError.ClientID%>").style.color = "Red";
                return false;
            }
            else {
                document.getElementById("<%= lblDateError.ClientID%>").innerHTML = "";
            }
        }
    </script>--%>


    <asp:HiddenField ID="hdID" runat="server" />

    <dx:ASPxPopupControl ID="OrderCosting" HeaderText="Order Costing" runat="server" ClientInstanceName="OrderCostingPopUp" CloseAction="CloseButton" Height="550px" Modal="True" Width="1050px" PopupHorizontalAlign="WindowCenter" PopupVerticalAlign="WindowCenter">
        <ContentCollection>
            <dx:PopupControlContentControl ID="PopUpControlEmployeeInfo" runat="server">
            </dx:PopupControlContentControl>
        </ContentCollection>
        <ClientSideEvents CloseUp="function(s, e) {                      
                        window.location.reload(true);
                    }" />
    </dx:ASPxPopupControl>

       <div>
                    <table class="table">
                        <tr>
                            <td><b>Project:</b></td>
                            <td colspan="3">
                                <asp:DropDownList ID="ddlProjectOrder" runat="server" Width="380px" Height="25px"></asp:DropDownList>
                            </td>
                            <td>
                                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="ddlProjectOrder" ErrorMessage="Please Select Project." Font-Size="12px"
                                    InitialValue="Select" Display="Dynamic" Style="color: Red;" vertical-align="top" SetFocusOnError="true" ValidationGroup="user"></asp:RequiredFieldValidator>
                            </td>
                        </tr>

                        <tr>
                            <td width="100px"><b>From Date :</b></td>
                            <td width="180px">
                                <asp:TextBox ID="txtFromOrder" runat="server" Width="120px" placeholder="dd-MMM-yyyy"></asp:TextBox>
                                <asp:ImageButton ID="ImageButton2" ImageUrl="../Images/calender.png" Width="20px" Height="25px" ImageAlign="AbsMiddle" runat="server" />
                                <asp:CalendarExtender ID="CalendarExtender2" runat="server" TargetControlID="txtFromOrder" PopupButtonID="ImageButton2" SkinID="we" Format="dd-MMM-yyyy"></asp:CalendarExtender>
                            </td>
                            <td width="80px"><b>To Date :</b></td>
                            <td width="180px">
                                <asp:TextBox ID="txtToOrder" runat="server" Width="120px" placeholder="dd-MMM-yyyy"></asp:TextBox>
                                <asp:ImageButton ID="ImageButton3" ImageUrl="../Images/calender.png" Width="20px" Height="25px" ImageAlign="AbsMiddle" runat="server" />
                                <asp:CalendarExtender ID="CalendarExtender3" runat="server" TargetControlID="txtToOrder" PopupButtonID="ImageButton3" SkinID="we" Format="dd-MMM-yyyy"></asp:CalendarExtender>
                            </td>
                            <td>
                                <asp:Label ID="Label1" runat="server"></asp:Label></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td colspan="3">
                                <asp:Button ID="btnShowOrder" runat="server" Text="Show" Width="100px" OnClick="btnShowOrder_Click" CssClass="btn btn-primary btn-corner" />
                                <asp:Button ID="btnExport" runat="server" Style="padding: 5px;" Text="Export To Excel" OnClick="btnExport_Click" CssClass="btn btn-primary btn-corner" Visible="True" /></td>
                            <td></td>
                        </tr>

                    </table>
                    
                    <div style="overflow: scroll;">
                        <dx:ASPxGridViewExporter ID="grdExport" runat="server" GridViewID="grdEditCosting" FileName="grdEditCosting"></dx:ASPxGridViewExporter>
                        <dx:ASPxGridView ID="grdManualCostingReport" runat="server" AutoGenerateColumns="false" EnableRowsCache="False" ClientInstanceName="ClientOrderNo" KeyFieldName="OrderID" Theme="Office2010Silver"
                            OnCustomButtonCallback="grdManualCostingReport_CustomButtonCallback1" OnCustomUnboundColumnData="grdManualCostingReport_CustomUnboundColumnData" ><%--SettingsPager-PageSizeItemSettings-ShowAllItem="true"--%>
                            <SettingsPager Mode="ShowAllRecords"></SettingsPager>
                             <Settings ShowFilterRow="false" ShowFilterRowMenu="false" HorizontalScrollBarMode="Auto"
                                VerticalScrollBarMode="Auto" VerticalScrollableHeight="400" />
                             <ClientSideEvents EndCallback="OnEndCallback" />
                            <Columns>
                                <dx:GridViewDataTextColumn FieldName="OrderID" Caption="Verify" VisibleIndex="1" Width="50px" Visible="false" Settings-ShowInFilterControl="False" Settings-AllowSort="False" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" >
                                    <Settings ShowInFilterControl="False" AllowSort="False"></Settings>
                                </dx:GridViewDataTextColumn>

                                <dx:GridViewCommandColumn Caption="View" ButtonType="link" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="50px">
                                    <CustomButtons>
                                        <dx:GridViewCommandColumnCustomButton Text="View" ID="Show" Image-ToolTip="Show Feedback"></dx:GridViewCommandColumnCustomButton>
                                    </CustomButtons>
                                </dx:GridViewCommandColumn>
                                <dx:GridViewDataTextColumn FieldName="OrderID" Caption="OrderID" Visible="false"  FixedStyle="Left"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="Number" VisibleIndex="0" CellStyle-HorizontalAlign="Center" Caption="Sr.#" Width="35px" UnboundType="String" ReadOnly="true" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ClientOrderNo" Caption="OrderNo" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="OrderDate" CellStyle-HorizontalAlign="Center" Caption="Received Date" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="SearchEngine" Caption="Search Engine" Width="200px" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="SearchType" Caption="SearchType" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="State" Caption="State" CellStyle-HorizontalAlign="Center" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="60px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="County" CellStyle-HorizontalAlign="Center" Caption="County" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="60px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="DeliveredDate" CellStyle-HorizontalAlign="Center" Caption="Dispatch Date" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="100px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="NoOfDocuments" CellStyle-HorizontalAlign="Center" Caption="NoofDoc" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="70px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="NoOfPages" CellStyle-HorizontalAlign="Center" Caption="NoofPages"  FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="70px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="TaxInformation" CellStyle-HorizontalAlign="Center" Caption="TaxInfo"  FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="70px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="CalledTaxes" CellStyle-HorizontalAlign="Center" Caption="Calling" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="70px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="BName" CellStyle-HorizontalAlign="Center" Caption="BorrowerName" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black" Width="100px"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="PropertyAddress" CellStyle-HorizontalAlign="Center" Caption="Address" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="OnOffLine" CellStyle-HorizontalAlign="Center" Caption="Online/Offline" FixedStyle="Left" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="PropertyType" Visible="false" CellStyle-HorizontalAlign="Center" Caption="Property Type" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ProductType" CellStyle-HorizontalAlign="Center" Caption="ProductType" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ProcessDone" CellStyle-HorizontalAlign="Center" Caption="ProcessDone" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>
                                <dx:GridViewDataTextColumn FieldName="ProcessStatus" CellStyle-HorizontalAlign="Center" Caption="Status" HeaderStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-ForeColor="Black"></dx:GridViewDataTextColumn>

                                <dx:GridViewBandColumn Caption="Production Costing" HeaderStyle-Font-Bold="true" HeaderStyle-Font-Size="Larger" HeaderStyle-HorizontalAlign="Center">
                                    <Columns>
                                        <dx:GridViewBandColumn Caption="Search Cost" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="SearchCostNoOfSearches" CellStyle-HorizontalAlign="Center" Caption="No Of Searches Made"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchCostCost" CellStyle-HorizontalAlign="Center" Caption="Cost/Search"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchCostTotal" CellStyle-HorizontalAlign="Center" CellStyle-Font-Bold="true" HeaderStyle-Font-Bold="true" Caption="Search Cost Total"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>

                                        <dx:GridViewBandColumn Caption="Search Copy Cost" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="SearchCopyCostPattern" CellStyle-HorizontalAlign="Center" Caption="Costing Pattern"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchCopyCostMainNo" Caption="No. Of Pages/Doc"></dx:GridViewDataTextColumn>
                                                <%--<dx:GridViewDataTextColumn FieldName="SearchCopyCostPagesDocsMain" CellStyle-HorizontalAlign="Center" Caption="Cost/Page Or Docs"></dx:GridViewDataTextColumn>--%>
                                                <dx:GridViewDataTextColumn FieldName="SearchCopyCostCostMain" CellStyle-HorizontalAlign="Center" Caption="Cost/Page Or Docs"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchCopyCostTotalMain" CellStyle-HorizontalAlign="Center" Caption="Total"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchCopyCostNo" Caption="No. Of Pages/Doc"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchCopyCostCost" CellStyle-HorizontalAlign="Center" Caption="Cost/Page Or Docs"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchCopyCostTotal" CellStyle-HorizontalAlign="Center" Caption="Total"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchTotalCost" CellStyle-HorizontalAlign="Center" CellStyle-Font-Bold="true" HeaderStyle-Font-Bold="true" Caption="Search Copy Cost Total"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>

                                        <dx:GridViewBandColumn Caption="Judgment Search Cost" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentSearchCostNoOfSeraches" CellStyle-HorizontalAlign="Center" Caption="No Of Searches Made"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentSearchCostCost" CellStyle-HorizontalAlign="Center" Caption="Cost/Search"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentSearchCostTotal" CellStyle-HorizontalAlign="Center" CellStyle-Font-Bold="true" HeaderStyle-Font-Bold="true" Caption="Judgment Search Cost Total"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>

                                        <dx:GridViewBandColumn Caption="Judgment Search Copy Cost" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentCopyCostPattern" CellStyle-HorizontalAlign="Center" Caption="Costing Pattern"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentCopyCostMainNo" Caption="No. Of Pages/Doc"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentCopyCostCostMain" CellStyle-HorizontalAlign="Center" Caption="Cost/Page Or Docs"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentCopyCostTotalMain" CellStyle-HorizontalAlign="Center" Caption="Total"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentCopyCostMainNo" Caption="No. Of Pages/Doc"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentCopyCostCost" CellStyle-HorizontalAlign="Center" Caption="Cost/Page Or Docs"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentCopyCostTotal" CellStyle-HorizontalAlign="Center" Caption="Total"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="JudgmentTotalCost" CellStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-Font-Bold="true" Caption="Judgment Search Copy Copy Total"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>

                                        <dx:GridViewBandColumn Caption="Tax Charges" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="TaxChargesDescription" CellStyle-HorizontalAlign="Center" Caption="Description"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="TaxAmount" CellStyle-HorizontalAlign="Center" Caption="Amount"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>

                                        <dx:GridViewBandColumn Caption="Other Charges" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="OtherChargesDescription" CellStyle-HorizontalAlign="Center" Caption="Description"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="OtherChargesAmount" CellStyle-HorizontalAlign="Center" Caption="Amount"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>
                                        <dx:GridViewDataTextColumn FieldName="Remark" CellStyle-HorizontalAlign="Center" Caption="Remark"></dx:GridViewDataTextColumn>
                                        <dx:GridViewDataTextColumn FieldName="ProductionCost" CellStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-Font-Bold="true" Caption="Production Cost"></dx:GridViewDataTextColumn>
                                    </Columns>
                                </dx:GridViewBandColumn>

                                <dx:GridViewBandColumn Caption="Abstractor Costing" HeaderStyle-Font-Bold="true" HeaderStyle-Font-Size="Larger" HeaderStyle-HorizontalAlign="Center">
                                    <Columns>
                                        <dx:GridViewBandColumn Caption="Search Cost" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="AbstractorSearchCost" CellStyle-HorizontalAlign="Center" Caption="Amount"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>

                                        <dx:GridViewBandColumn Caption="Search Copy Cost" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="AbstractorCopyCostPages" CellStyle-HorizontalAlign="Center" Caption="No Of Pages"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="AbstractorCopyCostCost" CellStyle-HorizontalAlign="Center" Caption="Total"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>

                                        <dx:GridViewBandColumn Caption="Other Cost" HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="OtherCost" CellStyle-HorizontalAlign="Center" Caption="Amount"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>
                                        <dx:GridViewDataTextColumn FieldName="AbstractorTotalCost" CellStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-Font-Bold="true" Caption="Abstractor Cost"></dx:GridViewDataTextColumn>
                                    </Columns>
                                </dx:GridViewBandColumn>

                                <dx:GridViewDataTextColumn FieldName="OrderCost" CellStyle-HorizontalAlign="Center" HeaderStyle-Font-Bold="true" CellStyle-Font-Bold="true" Caption="Total Cost"></dx:GridViewDataTextColumn>

                                <dx:GridViewBandColumn Caption="Credit Card Payment Information" HeaderStyle-Font-Bold="true" HeaderStyle-Font-Size="Larger" HeaderStyle-HorizontalAlign="Center">
                                    <Columns>
                                        <dx:GridViewBandColumn Caption=" " HeaderStyle-Font-Bold="true" HeaderStyle-HorizontalAlign="Center">
                                            <Columns>
                                                <dx:GridViewDataTextColumn FieldName="NameOfTheCard" CellStyle-HorizontalAlign="Center" Caption="Name of the Card"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="CreditCardNo" CellStyle-HorizontalAlign="Center" Caption="Credit Card No."></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="NameOfThePlant" CellStyle-HorizontalAlign="Center" Caption="Name Of The Plant"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="SearchingAmount" CellStyle-HorizontalAlign="Center" Caption="Searching Amount"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="DownloadingAmount" CellStyle-HorizontalAlign="Center" Caption="Downloading Amount"></dx:GridViewDataTextColumn>
                                                <dx:GridViewDataTextColumn FieldName="CRValidUpTo" CellStyle-HorizontalAlign="Center" Caption="Valid Up To"></dx:GridViewDataTextColumn>
                                            </Columns>
                                        </dx:GridViewBandColumn>
                                    </Columns>
                                </dx:GridViewBandColumn>
                            </Columns>
                        </dx:ASPxGridView>
                    </div>
      </div>

    


</div>
