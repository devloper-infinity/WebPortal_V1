SearchDashboard - Actual Server-Side Merge

Copy all files in this package to the existing ~/OST folder.

Main page:
  SearchDashboard.aspx

This version does NOT use iframes. Each original page was converted to an ASP.NET UserControl and loaded into SearchDashboard.aspx inside the selected tab. Existing server controls and event handlers remain isolated in their own naming container, preventing duplicate-ID conflicts.

Files:
- SearchDashboard.aspx / .cs / .css / .js
- ucOrderAllocationTest.ascx / .cs
- ucProcessOrderPM.ascx / .cs
- ucUploadAndDownloadSearch.ascx / .cs
- ucEditCosting.ascx / .cs

Important:
- Keep the four original pages until testing is complete because some legacy redirects may still point to workflow pages outside this dashboard.
- Add your menu link to ~/OST/SearchDashboard.aspx.
