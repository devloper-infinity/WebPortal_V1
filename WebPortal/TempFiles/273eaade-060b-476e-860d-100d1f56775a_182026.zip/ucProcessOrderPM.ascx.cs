using DevExpress.Web;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class ucProcessOrderPM : System.Web.UI.UserControl
{
    protected ClientScriptManager ClientScript { get { return Page.ClientScript; } }

    bllOST bllost = new bllOST();
    bllMaster bllmaster = new bllMaster();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblError.Text = "";
        if (!IsPostBack)
        {
            BindProject();
            if (drpProject.Text != "Select")
            {
                GetAllOrders();
            }
            GetAllProcess();
            GetUsers();
            cancelledBy.Style.Add("display", "none");
            reason.Style.Add("display", "none");
        }
        if (ddlOrderNo.SelectedIndex != 0 && ddlOrderNo.Text != "")
        {
            BindDataForOrder();
            BindGridOrderwise(Convert.ToInt32(ddlOrderNo.SelectedValue));
        }

        drpProject.Focus();


    }

    public void GetAllOrders()
    {
        ddlOrderNo.Items.Clear();
        if (drpProject.SelectedItem.Text != "Select")
        {

            //DataTable dtgrd = new DataTable();
            //dtgrd = bllost.GetOrders(int.Parse(HttpContext.Current.User.Identity.Name.ToString()));
            //dtgrd = bllost.GetOrdersOnProject(int.Parse(HttpContext.Current.User.Identity.Name.ToString()), Convert.ToString(drpProject.SelectedItem.Text));
            // ddlOrderNo.Items.Add(new ListItem(Convert.ToString(dtgrd.Rows[i]["ClientOrderNo"]), Convert.ToString(dtgrd.Rows[i]["OrderID"])));    

            ddlOrderNo.DataSource = bllost.GetOrdersOnProject(int.Parse(HttpContext.Current.User.Identity.Name.ToString()), Convert.ToString(drpProject.SelectedItem.Text));
            ddlOrderNo.DataTextField = "ClientOrderNo";
            ddlOrderNo.DataValueField = "OrderID";
            ddlOrderNo.DataBind();
            ddlOrderNo.Items.Insert(0, new ListItem("Select"));
        }
    }

    public void GetAllProcess()
    {
        try
        {
            DataTable dt = bllost.GetAllProcess();
            if (dt.Rows.Count > 0)
            {
                drpProcess.DataSource = dt;
                drpProcess.DataTextField = "ProcessName";
                drpProcess.DataValueField = "Processid";
                drpProcess.DataBind();
                drpProcess.Items.Insert(0, new ListItem("Select"));
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    public void GetUsers()
    {
        try
        {
            DataTable dt = bllost.GetUsersOnUserType("Searcher");
            DataTable dt1 = bllost.GetUsersOnUserType("PM");
            DataTable dt2 = bllost.GetUsersOnUserType("VM");
            DataTable dt3 = bllost.GetUsersOnUserType("Vendor");
            dt.Merge(dt1);
            dt.Merge(dt2);
            //dt.Merge(dt3);
            if (dt3.Rows.Count > 0)
            {
                for (int j = 0; j < dt3.Rows.Count; j++)
                {
                    ddlUser.Items.Add(new ListItem(Convert.ToString(dt3.Rows[j]["Code"]) + " : " + Convert.ToString(dt3.Rows[j]["FirstName"]) + " " + Convert.ToString(dt3.Rows[j]["MiddleName"]) + " " + Convert.ToString(dt3.Rows[j]["lastName"]), Convert.ToString(dt3.Rows[j]["EmployeeID"])));
                }
            }
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ddlUser.Items.Add(new ListItem(Convert.ToString(dt.Rows[i]["Code"]) + " : " + Convert.ToString(dt.Rows[i]["FirstName"]) + " " + Convert.ToString(dt.Rows[i]["MiddleName"]) + " " + Convert.ToString(dt.Rows[i]["lastName"]), Convert.ToString(dt.Rows[i]["EmployeeID"])));
                }
            }
            ddlUser.Items.Insert(0, new ListItem("Select"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    public void BindDataForOrder()
    {
        try
        {
            GridViewDataColumn column = null;
            ASPxCheckBox cb = null;

            DataTable dt2 = bllost.GetCurrentProcessOfUserPM(Convert.ToInt32(ddlOrderNo.SelectedValue));
            if (dt2.Rows.Count > 0)
            {
                drpProcess.SelectedValue = Convert.ToString(dt2.Rows[0]["Processid"]);
                // drpProcess.SelectedItem.Text = Convert.ToString(dt2.Rows[0]["ProcessName"]);
                Session["ProcessId"] = dt2.Rows[0]["Processid"];
                ddlUser.SelectedValue = Convert.ToString(dt2.Rows[0]["TaskAssignedId"]);

            }

            DataTable dt = bllost.GetOrdersOnProcess(Convert.ToInt32(ddlOrderNo.SelectedValue), Convert.ToInt32(Session["ProcessId"]));
            if (dt.Rows.Count > 0)
            {
                grdProcessOrder.DataSource = dt;
                grdProcessOrder.DataBind();
                Session["Orderid"] = dt.Rows[0]["OrderID"];
            }
            // chkDispatch.Checked = false;

            if (drpProcess.SelectedItem.Text == "Dispatch")
            {
                for (int rowIndex = 0; rowIndex < grdProcessOrder.VisibleRowCount; rowIndex++)
                {
                    column = (GridViewDataColumn)grdProcessOrder.Columns[0];
                    cb = (ASPxCheckBox)grdProcessOrder.FindRowCellTemplateControl(rowIndex, column, "CheckBox1");
                    cb.Checked = true;
                    cb.Enabled = false;
                }

                ASPxCheckBox ChkBoxHeader = (ASPxCheckBox)grdProcessOrder.FindHeaderTemplateControl((GridViewColumn)grdProcessOrder.Columns[0], "CheckBox2");
                ChkBoxHeader.Checked = true;
                ChkBoxHeader.Enabled = false;
                chkDispatch.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    protected void lnkAttachment_Click(object sender, EventArgs e)
    {
        string filePath = (sender as LinkButton).Text;
        Response.ContentType = ContentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
        Response.WriteFile(filePath);
        Response.End();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        #region Update Task Status and Date
        try
        {
            int Taskid = Convert.ToInt32(Session["TaskId"]);
            Hashtable htparam = new Hashtable();
            htparam["TaskId"] = Taskid;
            htparam["TaskStatus"] = drpStatus.SelectedValue;
            htparam["TaskAssignedId"] = drpCaller.SelectedValue;
            string Document1 = Convert.ToString(Session["DocumentType"]);
            string Process1 = Convert.ToString(Session["Process"]);
            htparam["Remark"] = Document1 + " is Transfer to " + drpCaller.SelectedItem.Text + " for Calling Process";
            int ReturnValue = bllost.UpdateTaskStatusAndDate(htparam);
            if (ReturnValue > 0)
            {
                dvError.Style.Add("display", "");
                lblError.Text = "Process Completed Successfully!";
                lblError.Visible = true;
                dvError.Visible = true;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                lblError.ForeColor = Color.Green;

                int Orderid = Convert.ToInt32(Session["OrderId"]);
                int TaskProcessid = Convert.ToInt32(Session["TaskProcessId"]);
                int AddedBy = int.Parse(HttpContext.Current.User.Identity.Name.ToString());
                int DocId = Convert.ToInt32(Session["DocId"]);

                #region Code For Insert Attachment
                string Attachment;
                if (fldAttachment.HasFile)
                {
                    if (!Directory.Exists(Server.MapPath(@"~\OSTAttachment\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + Orderid)))
                        Directory.CreateDirectory(Server.MapPath(@"~\OSTAttachment\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + Orderid));
                    fldAttachment.SaveAs(Server.MapPath(@"~\OSTAttachment\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + Orderid + "\\" + fldAttachment.FileName));
                    Attachment = "~\\OSTAttachment\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + Orderid + "\\" + fldAttachment.FileName;
                    string Attachment1 = Server.MapPath(@"~\OSTAttachment\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + Orderid + "\\" + fldAttachment.FileName);
                }
                else
                {
                    Attachment = "";
                }
                if (Attachment != "")
                {
                    new InsertOSTtask().InsertOSTAttachment(Orderid, TaskProcessid, DocId, Attachment, "Process " + drpStatus.SelectedItem.Text, AddedBy);
                }
                #endregion

                #region Add Comment
                string Document = Convert.ToString(Session["DocumentType"]);
                string Process = Convert.ToString(Session["Process"]);
                string Comment = Process + " Process of " + Document + " Document has been " + drpStatus.SelectedItem.Text;
                new InsertOSTtask().InsertComment(Orderid, TaskProcessid, "Auto", Comment, AddedBy);
                #endregion

            }
            Response.Redirect("SearchDashboard.aspx?tab=ProcessOrderPM");
        }
        catch (Exception ex)
        {
            ex.Message.ToString();

        }

        #endregion
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            int ReturnValue = -1;
            int TaskStatus = 0;
            int AddedBy = 0;
            if (ddlOrderNo.SelectedIndex != 0)
            {
                string confirmValue = Request.Form["confirmCancel_value"];
                string holdConfirmValue = Request.Form["confirmHold_value"];

                AddedBy = int.Parse(HttpContext.Current.User.Identity.Name.ToString());
                List<ASPxCheckBox> selectedCheckBoxes = new List<ASPxCheckBox>();
                GridViewDataColumn column = null;
                ASPxCheckBox cb = null;
                Label lb = null;
                if (fldFileAttach.FileName != "")
                {
                    string orderNo = Convert.ToString(grdProcessOrder.GetRowValues(0, "ClientOrderNo"));
                    if (fldFileAttach.FileName != "")
                    {
                        string AttachOrderNo;
                        string AttachOrderNo1;
                        int indexof;

                        AttachOrderNo = fldFileAttach.FileName;
                        indexof = AttachOrderNo.LastIndexOf(".");
                        AttachOrderNo1 = AttachOrderNo.Substring(0, indexof);

                        if (orderNo.ToLower() == AttachOrderNo1.ToLower())
                        {

                        }
                        else
                        {

                            string TextComment = string.Empty;
                            string Comment = "Process Order PM :Exception:" + drpProcess.SelectedItem.Text + ":" + "The selected file Name does not match with the Order No-" + " By PM Login";
                            new InsertOSTtask().InsertComment(Convert.ToInt32(ddlOrderNo.SelectedValue), Convert.ToInt32(drpProcess.SelectedValue), "Auto", Comment, AddedBy);

                            dvError.Style.Add("display", "");
                            lblError.Text = "The selected file Name does not match with the Order No.";
                            lblError.Visible = true;
                            dvError.Visible = true;
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                            lblError.ForeColor = Color.Red;
                            return;

                        }

                    }

              

                    for (int rowIndex = 0; rowIndex < grdProcessOrder.VisibleRowCount; rowIndex++)
                    {
                        column = (GridViewDataColumn)grdProcessOrder.Columns[0];
                        cb = (ASPxCheckBox)grdProcessOrder.FindRowCellTemplateControl(rowIndex, column, "CheckBox1");
                        if (cb.Checked == true)
                        {
                            lb = (Label)grdProcessOrder.FindRowCellTemplateControl(rowIndex, column, "lblID");
                            int Taskid = Convert.ToInt32(grdProcessOrder.GetRowValues(rowIndex, "Taskid"));
                            int DocId = Convert.ToInt32(grdProcessOrder.GetRowValues(rowIndex, "Docid"));
                            string ProjectName = Convert.ToString(grdProcessOrder.GetRowValues(rowIndex, "Project"));
                            string Project = Convert.ToString(new bllMaster().ValidateProject(ProjectName));
                            if (Project != "0")
                            {
                                string EmployeeHadProjectRights = new bllMaster().ValidateUserProjectRights(Convert.ToString(ddlUser.SelectedItem.Text.Substring(0, 4).Replace(':', ' ').Trim()), Project);
                                if (EmployeeHadProjectRights != "0")
                                {

                                    Hashtable htparam = new Hashtable();
                                    htparam["TaskId"] = Taskid;
                                    if (chkCancel.Checked == true)
                                    {
                                        htparam["TaskStatus"] = 5;
                                        TaskStatus = 5;
                                    }
                                    else if (chkHold.Checked == true)
                                    {
                                        htparam["TaskStatus"] = 4;
                                        TaskStatus = 4;
                                    }
                                    else
                                    {
                                        htparam["TaskStatus"] = 2;
                                        TaskStatus = 2;
                                    }
                                    
                                    

                                    htparam["TaskAssignedId"] = 0;
                                    htparam["Remark"] = AddedBy + ':' + txtTaskRemark.Text.Trim();
                                    ReturnValue = bllost.UpdateTaskStatusAndDate(htparam);
                                    if (ReturnValue > 0)
                                    {
                                        dvError.Style.Add("display", "");
                                        lblError.Text = "Process Completed Successfully!";
                                        lblError.Visible = true;
                                        dvError.Visible = true;
                                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                                        lblError.ForeColor = Color.Green;

                                    }
                                }
                                else
                                {
                                    dvError.Style.Add("display", "");
                                    lblError.Text = ProjectName + " Project is not assign to user.";
                                    lblError.Visible = true;
                                    dvError.Visible = true;
                                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                                    lblError.ForeColor = Color.Red;
                                }
                            }
                        }
                    }

                    if (ReturnValue > 0)
                    {
                        #region Add Comment
                        string TextComment = string.Empty;
                        string Comment = drpProcess.SelectedItem.Text + " " + "Process Completed" + " By PM Login";
                        new InsertOSTtask().InsertComment(Convert.ToInt32(ddlOrderNo.SelectedValue), Convert.ToInt32(drpProcess.SelectedValue), "Auto", Comment, AddedBy);

                        if (chkHold.Checked == true)
                        {
                            TextComment = "Order is on Hold By PM Login";
                            new InsertOSTtask().InsertComment(Convert.ToInt32(ddlOrderNo.SelectedValue), Convert.ToInt32(drpProcess.SelectedValue), "Auto", TextComment, AddedBy);
                        }
                        #endregion

                        #region Code For Insert Attachment
                        string Attachment;
                        if (fldFileAttach.HasFile)
                        {
                           
                            if (!Directory.Exists(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text)))
                            {
                                Directory.CreateDirectory(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text));
                            }

                            if (!Directory.Exists(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy"))))
                            {
                                Directory.CreateDirectory(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy")));
                            }

                            if (!Directory.Exists(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + ddlOrderNo.SelectedValue)))
                            {
                                Directory.CreateDirectory(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + ddlOrderNo.SelectedValue));
                            }

                            fldFileAttach.SaveAs(Server.MapPath(@"~\OSTAttachment\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + ddlOrderNo.SelectedValue + "\\" + fldFileAttach.FileName));
                            Attachment = "~\\OSTAttachment\\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + ddlOrderNo.SelectedValue + "\\" + fldFileAttach.FileName;
                            string Attachment1 = Server.MapPath(@"~\\OSTAttachment\\" + drpProcess.SelectedItem.Text + "\\" + DateTime.Now.ToString("dd-MMM-yyyy") + "\\" + ddlOrderNo.SelectedValue + "\\" + fldFileAttach.FileName);
                        }
                        else
                        {
                            Attachment = "";
                        }
                        if (Attachment != "")
                        {
                            new InsertOSTtask().InsertOSTAttachment(Convert.ToInt32(ddlOrderNo.SelectedValue), Convert.ToInt32(drpProcess.SelectedValue), TaskStatus, Attachment, "Process Completed", AddedBy);
                        }
                        #endregion

                        //if (chkDispatch.Checked == true)
                        //{
                        //    DispatchOrder();
                        //}

                        if (chkCancel.Checked == true)
                        {
                            CancelOrder();
                        }
                        
                    }
                    if (ReturnValue > 0)
                    {
                        if (drpProcess.Text == "2" || drpProcess.Text == "11" || drpProcess.Text=="5")
                        {
                          
                              if (chkDispatch.Checked == true)
                               {
                                    DispatchOrder();
                               }

                             if (ChkNoError.Checked == true)
                             {
                                FeedBackOrders();
                             }
                            else
                            {
                                string OrderNo = Convert.ToString(grdProcessOrder.GetRowValues(0, "ClientOrderNo"));
                                string ProjectName = Convert.ToString(grdProcessOrder.GetRowValues(0, "Project"));
                                Response.Redirect("~/OST/AddFeedbackForSearchProject.aspx?ProcessFeedbak=" + OrderNo + "&ProjectName=" + ProjectName + "&Process=" + drpProcess.Text);
                            }
                        }
                        ClearFields();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            string TextComment = string.Empty;
            string Comment = "Process Order PM :Exception:" + drpProcess.SelectedItem.Text + ":" +  ex.Message.ToString() +" By PM Login";
            new InsertOSTtask().InsertComment(Convert.ToInt32(ddlOrderNo.SelectedValue), Convert.ToInt32(drpProcess.SelectedValue), "Auto", Comment, 2);
        }
    }

    public void ClearFields()
    {
        drpProject.SelectedIndex = 0;
        ddlOrderNo.SelectedIndex = 0;
        drpProcess.SelectedIndex = 0;
        ddlUser.SelectedIndex = -1;
        txtTaskRemark.Text = "";
        chkDispatch.Checked = false;
        chkCancel.Checked = false;
        chkHold.Checked = false;
        ChkNoError.Checked = false;
    }
    protected void drpStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpStatus.SelectedIndex != 0)
        {
            if (drpStatus.SelectedItem.Text == "Transfer")
            {
                drpCaller.Visible = true;
                BindUsers();
            }
        }
    }

    public void BindUsers()  /// Bind All Production Employee
    {
        try
        {
            DataTable dtgrd = new DataTable();
            dtgrd = bllost.GetAllInfinityCaller();
            if (dtgrd.Rows.Count > 0)
            {
                for (int i = 0; i < dtgrd.Rows.Count; i++)
                {
                    drpCaller.Items.Add(new ListItem(Convert.ToString(dtgrd.Rows[i]["Employee"]), Convert.ToString(dtgrd.Rows[i]["UserId"])));
                }
            }
            drpCaller.Items.Insert(0, new ListItem("Select"));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    //protected void drpOrder_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (drpOrder.SelectedIndex > 0)
    //        {
    //            int OrderID = Convert.ToInt32(drpOrder.SelectedValue);

    //            BindGridOrderwise(OrderID);
    //            lblError.Text = string.Empty;
    //        }
    //        else
    //        {
    //            drpProcess.SelectedIndex = 0;
    //            lnkViewDetails.Visible = false;
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ex.Message.ToString();
    //    }
    //}

    public void BindGridOrderwise(int OrderID)
    {
        try
        {
            GridViewDataColumn column = null;
            ASPxCheckBox cb = null;

            DataTable dt2 = bllost.GetCurrentProcessOfUser(OrderID, Convert.ToInt32(HttpContext.Current.User.Identity.Name));
            if (dt2.Rows.Count > 0)
            {
                drpProcess.SelectedValue = Convert.ToString(dt2.Rows[0]["Processid"]);
                Session["ProcessId"] = dt2.Rows[0]["Processid"];
            }

            DataTable dt = bllost.GetOrdersOnProcessForUser(OrderID, int.Parse(HttpContext.Current.User.Identity.Name.ToString()), Convert.ToInt32(Session["ProcessId"]));
            if (dt.Rows.Count > 0)
            {
                grdProcessOrder.DataSource = dt;
                grdProcessOrder.DataBind();
                Session["Orderid"] = dt.Rows[0]["OrderID"];
            }
            //chkDispatch.Checked = false;

            if (drpProcess.SelectedItem.Text == "Dispatch")
            {
                for (int rowIndex = 0; rowIndex < grdProcessOrder.VisibleRowCount; rowIndex++)
                {
                    column = (GridViewDataColumn)grdProcessOrder.Columns[0];
                    cb = (ASPxCheckBox)grdProcessOrder.FindRowCellTemplateControl(rowIndex, column, "CheckBox1");
                    cb.Checked = true;
                    cb.Enabled = false;
                }

                ASPxCheckBox ChkBoxHeader = (ASPxCheckBox)grdProcessOrder.FindHeaderTemplateControl((GridViewColumn)grdProcessOrder.Columns[0], "CheckBox2");
                ChkBoxHeader.Checked = true;
                ChkBoxHeader.Enabled = false;
                chkDispatch.Enabled = false;
            }

            BindOrderDetailsReport(Convert.ToInt32(OrderID));
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    protected void grdProcessOrder_CustomCallback(object sender, ASPxGridViewCustomCallbackEventArgs e)
    {
        int index = -1;
        if (int.TryParse(e.Parameters, out index))
            grdProcessOrder.SettingsEditing.Mode = (GridViewEditingMode)index;
    }

    protected void grdProcessOrder_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }

    protected void grdProcessOrder_HtmlRowPrepared(object sender, ASPxGridViewTableRowEventArgs e)
    {
        string TaskAssigned = Convert.ToString(e.GetValue("TransferAssignedId"));
        if (TaskAssigned != "")
        {
            e.Row.BackColor = Color.Yellow;
            e.Row.Enabled = false;
        }
    }

    protected void grdProcessOrder_CustomButtonCallback(object sender, ASPxGridViewCustomButtonCallbackEventArgs e)
    {
        if (e.ButtonID == "Status")
        {
            string Taskid = grdProcessOrder.GetRowValues(e.VisibleIndex, "Taskid").ToString();
        }
    }

    protected void callbackPanel_Callback(object source, DevExpress.Web.CallbackEventArgsBase e)
    {
        try
        {
            int Taskid = Convert.ToInt32(e.Parameter);
            Session["TaskId"] = Taskid;
            DataTable dt = bllost.GetDetailsFromTask(Taskid);
            if (dt.Rows.Count > 0)
            {
                string Orderid = Convert.ToString(dt.Rows[0]["Orderid"]);
                Session["OrderId"] = Orderid;
                string Process = Convert.ToString(dt.Rows[0]["ProcessName"]);
                Session["Process"] = Process;
                int TaskProcessId = Convert.ToInt32(dt.Rows[0]["TaskProcessid"]);
                Session["TaskProcessId"] = TaskProcessId;
                int DocId = Convert.ToInt32(dt.Rows[0]["Docid"]);
                Session["DocId"] = DocId;
                string DocumentType = Convert.ToString(dt.Rows[0]["DocumentType"]);
                Session["DocumentType"] = DocumentType;
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    public void DispatchOrder()
    {
        string confirmValue = Request.Form["confirm_value"];
        //if (confirmValue == "Yes")
        //{
            int orderID = Convert.ToInt32(Session["Orderid"]);
            if (orderID > 0 && ddlOrderNo.SelectedIndex > 0)
            {
                Hashtable HtSheet = new Hashtable();

                HtSheet.Add("OrderId", orderID);
                HtSheet.Add("TaskTemplateid", 0);
                HtSheet.Add("TaskAssignedId", ddlUser.SelectedValue);
                HtSheet.Add("Remark", txtTaskRemark.Text.Trim());
                HtSheet.Add("AdddedBy", HttpContext.Current.User.Identity.Name);

                int ReturnValue = bllost.DispatchOrderTask(HtSheet);
                if (ReturnValue > 0)
                {
                    string TextComment = "Order is Dispatched by PM Login";
                    new InsertOSTtask().InsertComment(Convert.ToInt32(ddlOrderNo.SelectedValue),
                                                      6,
                                                      "Auto",
                                                      TextComment,
                                                      Convert.ToInt32(HttpContext.Current.User.Identity.Name));

                    dvError.Style.Add("display", "");
                    lblError.Text = "Order dispatched successfully!";
                    lblError.Visible = true;
                    dvError.Visible = true;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                    lblError.ForeColor = Color.Green;
                    chkDispatch.Checked = false;
                    Response.Redirect("SearchDashboard.aspx?tab=ProcessOrderPM");
                }
                else
                {
                    dvError.Style.Add("display", "");
                    lblError.Text = "Order is not dispatched!";
                    lblError.Visible = true;
                    dvError.Visible = true;
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                    lblError.ForeColor = Color.Red;
                }
            }
       // }
    }

    public void CancelOrder()
    {
        try
        {
            //string confirmValue = Request.Form["confirmCancel_value"];
            //if (confirmValue == "Yes")
            //{
                int orderID = Convert.ToInt32(Session["Orderid"]);
                if (orderID > 0 && ddlOrderNo.SelectedIndex > 0)
                {
                    Hashtable htparam = new Hashtable();
                    string processName = string.Empty;

                    htparam["OrderID"] = orderID;

                    StringBuilder reason = new StringBuilder();
                    reason.Append(int.Parse(HttpContext.Current.User.Identity.Name.ToString()));

                    reason.Append(",");
                    reason.Append(ddlApprove.SelectedValue);

                    if (!string.IsNullOrEmpty(txtReason.Text))
                    {
                        reason.Append(",");
                        reason.Append(txtReason.Text.Trim());
                    }

                    htparam["Status"] = "Approve";
                    htparam["Reason"] = reason;

                    int ReturnValue = bllost.CancelOrder(htparam);
                    if (ReturnValue == 1)
                    {
                        string TextComment = "Order is Cancelled by PM";
                        new InsertOSTtask().InsertComment(orderID, Convert.ToInt32(drpProcess.SelectedValue), "Auto", TextComment, int.Parse(HttpContext.Current.User.Identity.Name.ToString()));

                    }
                }
            //}
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }

    public void FeedBackOrders()
    {
        int AddedBy = int.Parse(HttpContext.Current.User.Identity.Name.ToString());
        int Taskid = Convert.ToInt32(grdProcessOrder.GetRowValues(0, "Taskid"));
        string ProjectName = Convert.ToString(grdProcessOrder.GetRowValues(0, "Project"));
        string OrderNo = Convert.ToString(grdProcessOrder.GetRowValues(0, "ClientOrderNo"));
        string ProcessName = drpProcess.Text;
        int orderID = Convert.ToInt32(Session["Orderid"]);
        if (orderID > 0)
        {

            Hashtable HtSheet = new Hashtable();
            HtSheet.Add("OrderNo", OrderNo);
            HtSheet.Add("ProjectName", ProjectName);
            HtSheet.Add("ProcessName", ProcessName);
            HtSheet.Add("AddedBy", AddedBy);
            HtSheet.Add("OrderId", orderID);

            int ReturnValue = bllost.FeedBackOrders(HtSheet);
            if (ReturnValue > 0)
            {

                dvError.Style.Add("display", "");
                lblError.Text = "Feedback Addded successfully!";
                lblError.Visible = true;
                dvError.Visible = true;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                lblError.ForeColor = Color.Green;
                ChkNoError.Checked = false;
                Response.Redirect("~/OST/ProcessOrder.aspx");
            }
            else
            {
                dvError.Style.Add("display", "");
                lblError.Text = "Error in Feedback Added!!!";
                lblError.Visible = true;
                dvError.Visible = true;
                ClientScript.RegisterStartupScript(this.GetType(), "alert", "HideLabel();", true);
                lblError.ForeColor = Color.Red;

            }

        }

    }

    private void BindOrderDetailsReport(int OrderID)
    {
        DataTable dt = bllost.GetOrderDetailsProcesswise(OrderID);
        if (dt.Rows.Count > 0)
        {
            grdOrderReportDetails.DataSource = dt;
            grdOrderReportDetails.DataBind();
            //lblCommentRecord.Text = "Total No of Records: " + dt.Rows.Count;
        }
    }

    protected void grdOrderReportDetails_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }

    protected void grdOrderReportDetails_HtmlRowPrepared(object sender, ASPxGridViewTableRowEventArgs e)
    {
        try
        {
            if (e.RowType == GridViewRowType.Data)
            {
                LinkButton lnkAttachment = (LinkButton)grdOrderReportDetails.FindRowCellTemplateControl(e.VisibleIndex, null, "lnkAttachment");
                string attachmentPath = lnkAttachment.Text;
                if (!String.IsNullOrEmpty(attachmentPath))
                {
                    string fileName = attachmentPath.Substring(attachmentPath.LastIndexOf("\\") + 1);
                    lnkAttachment.Text = fileName;
                    lnkAttachment.Style.Add("Color", "Blue");
                }

                LinkButton linkOrderSheet = (LinkButton)grdOrderReportDetails.FindRowCellTemplateControl(e.VisibleIndex, null, "linkOrderSheet");
                string attachmentPath1 = linkOrderSheet.Text;
                if (!String.IsNullOrEmpty(attachmentPath1))
                {
                    string fileName = attachmentPath1.Substring(attachmentPath1.LastIndexOf("\\") + 1);
                    linkOrderSheet.Text = fileName;
                    linkOrderSheet.Style.Add("Color", "Blue");
                }

            }
        }
        catch (Exception Ex)
        {
            Ex.Message.ToString();
        }
    }

    public void BindProject()    /////Bind All Project From Client Profile (OST)
    {

        try
        {
            DataTable dt = bllost.GetAllProject(int.Parse(HttpContext.Current.User.Identity.Name.ToString()));
            drpProject.DataSource = dt;
            drpProject.DataTextField = "ProjectName";
            drpProject.DataValueField = "ProjectID";
            drpProject.DataBind();
            //drpProject.Items.Insert(0, new ListItem("Select"));
            drpProject.Items.Insert(0, new ListItem("Select", "0"));
            //drpProcess.SelectedIndex = 0;
            //ddlUser.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }

    }
    protected void drpProject_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpProject.Text != "Select")
        {
            GetAllOrders();
        }
    }
    protected void ddlOrderNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlOrderNo.SelectedIndex > 0)
            {
                int OrderID = Convert.ToInt32(ddlOrderNo.SelectedValue);

                BindGridOrderwise(OrderID);
                BindDataForOrder();
                lblError.Text = string.Empty;
            }
            else
            {
                drpProcess.SelectedIndex = 0;
                lnkViewDetails.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
    }
    protected void linkOrderSheet_Click(object sender, EventArgs e)
    {
        string filePath = (sender as LinkButton).Text;
        Response.ContentType = ContentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
        Response.WriteFile(filePath);
        Response.End();
    }
}