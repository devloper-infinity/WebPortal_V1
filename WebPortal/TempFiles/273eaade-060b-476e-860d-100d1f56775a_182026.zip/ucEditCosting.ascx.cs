using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using DevExpress.Web;
using System.IO;
using System.Text;
using DevExpress.XtraPrinting;
using DevExpress.XtraPrintingLinks;
using System.Text.RegularExpressions;

public partial class ucEditCosting : System.Web.UI.UserControl
{
    protected ClientScriptManager ClientScript { get { return Page.ClientScript; } }

    bllOST bllost = new bllOST();
    BLLTMM BLLTMM = new BLLTMM();

    string dropdownlstCost, FromDateCost, ToDateCost;
    string dropdownlst, frodate, tdate;
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {
            BindProject();

            frodate = HttpUtility.UrlDecode(Request.QueryString["fd"]);
            tdate = HttpUtility.UrlDecode(Request.QueryString["td"]);
            dropdownlst = HttpUtility.UrlDecode(Request.QueryString["ddl"]);

            if (frodate != string.Empty && frodate != null && tdate != string.Empty && tdate != null && dropdownlst != "")
            {
                BindProjectWiseGrid(Convert.ToString(dropdownlst), Convert.ToString(frodate).Trim(), Convert.ToString(tdate).Trim());
            }
        }
        if (dropdownlstCost != null)
        {
            txtFromOrder.Text = FromDateCost;
            txtToOrder.Text = ToDateCost;
            ddlProjectOrder.Text = dropdownlstCost;
           
        }
        FromDateCost = Convert.ToString(Request.Form[txtFromOrder.UniqueID]);
        ToDateCost = Convert.ToString(Request.Form[txtToOrder.UniqueID]);
        dropdownlstCost = Convert.ToString(Request.Form[ddlProjectOrder.UniqueID]);

        if (ddlProjectOrder.SelectedIndex > 0 && FromDateCost != string.Empty && FromDateCost != null && ToDateCost != string.Empty && ToDateCost != null)
        {
            BindProjectWiseGrid(Convert.ToString(ddlProjectOrder.SelectedValue), Convert.ToString(Request.Form[txtFromOrder.UniqueID]).Trim(), Convert.ToString(Request.Form[txtToOrder.UniqueID]).Trim());
        }


    }



    public void BindProject()
    {
        ddlProjectOrder.Items.Clear();
        DataTable dt = bllost.GetAllProject(int.Parse(HttpContext.Current.User.Identity.Name.ToString()));
        if (dt.Rows.Count > 0)
        {

            ddlProjectOrder.DataSource = dt;
            ddlProjectOrder.DataTextField = "ProjectName";
            ddlProjectOrder.DataValueField = "ProjectName";
            ddlProjectOrder.DataBind();
            ddlProjectOrder.Items.Insert(0, new ListItem("Select"));


        }
    }



    protected void grdBillingSummary_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }


    protected void callbackPanel_Callback(object sender, CallbackEventArgsBase e)
    {

    }



    protected void grdEditCosting_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }
    public void BindProjectWiseGrid(string Project, string FromDate, string ToDate)
    {
        DataTable dt = BLLTMM.TMMGetProjectWiseOrderDetailsForBilling_EditCosting(Project, FromDate, ToDate);
        if (dt.Rows.Count > 0)
        {
            grdManualCostingReport.DataSource = dt;
            grdManualCostingReport.DataBind();
        }
        else
        {
            grdManualCostingReport.DataSource = null;
            grdManualCostingReport.DataBind();
        }
        ddlProjectOrder.Text = Project;
        txtFromOrder.Text = FromDate;
        txtToOrder.Text = ToDate;
    }
    protected void btnShowOrder_Click(object sender, EventArgs e)
    {
        //BindGrid1(txtFromOrder.Text.Trim(), txtToOrder.Text.Trim());
        string FromDate = Convert.ToString(Request.Form[txtFromOrder.UniqueID]).Trim();
        string ToDate = Convert.ToString(Request.Form[txtToOrder.UniqueID]).Trim();


        if (ddlProjectOrder.SelectedIndex > 0 && FromDate != string.Empty && FromDate != null && ToDate != string.Empty && ToDate != null)
        {
            BindProjectWiseGrid(Convert.ToString(ddlProjectOrder.SelectedValue), FromDate, ToDate);
        }



        txtFromOrder.Text = FromDate;
        txtToOrder.Text = ToDate;
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        var exportOptions = new XlsExportOptionsEx();
        exportOptions.ExportType = DevExpress.Export.ExportType.WYSIWYG;
        grdExport.WriteXlsToResponse(exportOptions);
    }
    protected void hyperLinkEditOrder_Init(object sender, EventArgs e)
    {

    }
    protected void grdManualCostingReport_CustomButtonCallback(object sender, ASPxGridViewCustomButtonCallbackEventArgs e)
    {
        if (e.ButtonID == "Show")
        {
            int OrderID = Convert.ToInt32(grdManualCostingReport.GetRowValues(e.VisibleIndex, "OrderID"));
            int ProcessId = Convert.ToInt32(grdManualCostingReport.GetRowValues(e.VisibleIndex, "ProcessId"));
            
            //ASPxGridView.RedirectOnCallback("EditOrderCosting.aspx?OrderID=" + OrderID);
            //ASPxGridView.RedirectOnCallback("EditOrderCosting.aspx?OrderID=" + OrderID + "&ddl=" + dropdownlstCost + "&fd=" + FromDateCost + "&td=" + ToDateCost);
            ASPxGridView.RedirectOnCallback("EditCostingNew.aspx?OrderID=" + OrderID + "&ddl=" + dropdownlstCost + "&fd=" + FromDateCost + "&td=" + ToDateCost);
        }
        else
        {

        }
    }
    protected void grdManualCostingReport_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
    {
        if (e.Column.FieldName == "Number")
        {
            e.Value = string.Format("{0}", e.ListSourceRowIndex + 1);
        }
    }
    protected void grdManualCostingReport_CustomButtonCallback1(object sender, ASPxGridViewCustomButtonCallbackEventArgs e)
    {
        if (e.ButtonID == "Show")
        {
            int OrderID = Convert.ToInt32(grdManualCostingReport.GetRowValues(e.VisibleIndex, "OrderID"));
            int ProcessId = 2;

            //ASPxGridView.RedirectOnCallback("EditOrderCosting.aspx?OrderID=" + OrderID);
            //ASPxGridView.RedirectOnCallback("EditOrderCosting.aspx?OrderID=" + OrderID + "&ddl=" + dropdownlstCost + "&fd=" + FromDateCost + "&td=" + ToDateCost);
            ASPxGridView.RedirectOnCallback("EditCostingNew.aspx?OrderID=" + OrderID + "&ddl=" + dropdownlstCost + "&fd=" + FromDateCost + "&td=" + ToDateCost);
        }
        else
        {

        }
    }
}